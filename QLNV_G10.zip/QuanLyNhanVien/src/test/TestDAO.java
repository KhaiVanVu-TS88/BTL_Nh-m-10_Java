package test;

import java.util.ArrayList;

import dao.ChamCongDAO;
import dao.NhanVienDAO;
import dao.TuyenDungDAO;
import model.ChamCong;
import model.NhanVien;
import model.TuyenDung;

public class TestDAO {
	public static void main(String[] args) {

		ArrayList<NhanVien> list = NhanVienDAO.getInstance().selectALL();
		for (NhanVien nhanVien : list) {
			System.out.println(nhanVien);
			
		}
		NhanVien nhanvien1 = new NhanVien();
		nhanvien1.setMaNhanVien("010");
		NhanVienDAO.getInstance().delete(nhanvien1);
		
//		for (int i = 40; i<60;i++) {
//			TuyenDung tuyenDung = new TuyenDung("TD00"+i, "Nguyễn Văn "+i, "098765432"+i, "nguyenvana"+i+"@gmail.com", "Nhan vien"+i, "Đại học", 1000+i, "Chua Tuyen");
//
//			TuyenDungDAO.getInstance().insert(tuyenDung);
//		}
		
		
//		TuyenDung tuyenDung = new TuyenDung("TD0012", "Nguyễn Văn Khai", "098765432456", "nguyenvana@gmail.com", "Nhân viên IT", "Đại học", 15000, "Tuyen");
//		
//		TuyenDungDAO.getInstance().update(tuyenDung);
		
//		TuyenDung tuyenDung = new TuyenDung();
//		tuyenDung.setMaTuyenDung("TD001");
//		ArrayList<TuyenDung> list =  TuyenDungDAO.getInstance().selectALL();
//		for (TuyenDung tuyenDung : list) {
//			System.out.println(tuyenDung);
//		}
		
		
//		NhanVien employee1 = new NhanVien("004","anh","nam","2024-12-25","vinhpuc","0358955666","KHCN","quan ly",2000);
//		NhanVien employee2 = new NhanVien("002","hoang","nu","2024-12-24","vinhphuc","0134654765","COKHI","quan ly",2000);
//		NhanVien employee3 = new NhanVien("005","ton","nu","2024-11-20","vinhphuc","03647576556","DIEN","quan ly",2000);
//		NhanVienDAO.getInstance().insert(employee1);
//		NhanVienDAO.getInstance().insert(employee2);
//		NhanVienDAO.getInstance().insert(employee3);
		
//		
//		ArrayList<ChamCong> list = ChamCongDAO.getInstance().selectALL();
//		for (ChamCong chamCong : list) {
//			System.out.println(chamCong);
//		}
		
/**		NhanVien employee1 = new NhanVien("004","anh","nam","2024-12-25","vinhpuc","0358955666","KHCN","quan ly",2000);
//		NhanVien employee2 = new NhanVien("002","hoang","nu","2024-12-24","vinhphuc","0134654765","COKHI","quan ly",2000);
//		NhanVien employee3 = new NhanVien("005","ton","nu","2024-11-20","vinhphuc","03647576556","DIEN","quan ly",2000);
//		NhanVienDAO.getInstance().insert(employee1);
//		NhanVienDAO.getInstance().insert(employee2);
//		NhanVienDAO.getInstance().insert(employee3);
		
//		NhanVien employee4 = new NhanVien("002","khon","nam","2014-12-25","vinhpuc","0358955666","KINHTE","quan ly",3000);
//		NhanVienDAO.getInstance().update(employee4);
		
//		NhanVien employe5 = new NhanVien();
//		employe5.setMaNhanVien("002");
//		NhanVienDAO.getInstance().delete(employe5);
		
//		ArrayList<NhanVien> list = NhanVienDAO.getInstance().selectALL();
//		for (NhanVien nhanVien : list) {
//			System.out.println(nhanVien.toString());
//		}
//		System.out.println("--------------");
//		NhanVien nhanVien = new NhanVien();
//		nhanVien.setMaNhanVien("005");
//		NhanVien nhanVienFindId = NhanVienDAO.getInstance().selectById(nhanVien);
//		System.out.println(nhanVienFindId.toString());
//		
//		System.out.println("--------------");
//		ArrayList<NhanVien> list1 = NhanVienDAO.getInstance().selectByCondition("GioiTinh = 'Nam'");
//		for (NhanVien nhanVien1 : list1) {
//			System.out.println(nhanVien1.toString());
//		}**/
	}
	
}

