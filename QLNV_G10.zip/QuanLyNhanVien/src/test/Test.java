package test;

import view.DangNhapView;
import view.ManHinhView;

public class Test {
	public static void main(String[] args) {
		new DangNhapView();
	}
}
 