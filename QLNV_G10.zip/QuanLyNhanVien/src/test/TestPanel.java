package test;

import javax.swing.JFrame;

import view.Panel_ChamCongView;
import view.Panel_LuongView;

import view.Panel_NhanVienView;
import view.Panel_PhongBanView;
import view.Panel_TaiKhoanView;
import view.Panel_TuyenDungView;

public class TestPanel {
	public static void main(String[] args) {
		JFrame jf = new JFrame(); 
		jf.setSize(1000,800);
		jf.setLocationRelativeTo(null);
		Panel_ChamCongView nv= new Panel_ChamCongView();
		jf.add(nv);
		
		jf.setVisible(true);
	}
}
