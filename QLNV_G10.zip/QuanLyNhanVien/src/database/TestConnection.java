package database;

import java.sql.Connection;

public class TestConnection {
	public static void main(String[] args) {
		Connection con = ConnectionDB.getConnection();
		System.out.println(con);
		ConnectionDB.printInfo(con);
		ConnectionDB.closeConnection(con);
		
	}
}
