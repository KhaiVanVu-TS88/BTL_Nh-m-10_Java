package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.cj.jdbc.Driver;

public class ConnectionDB {
	public static Connection getConnection() {
		Connection con= null;
		try {
			// đăng kí mySQL driver với  driverManager
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			
			// các thông số
			String url = "jdbc:mySQL://localhost:3306/qlnv6";
			String userName ="root";
			String passWord ="123456";
			
			// Tạo kết nối
			con = DriverManager.getConnection(url, userName, passWord);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return con;
	}
	
	public static void closeConnection(Connection con) {
		try {
			if(con !=null) {
				con.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	public static void printInfo(Connection c) {
		try {
			if(c!=null) {
				java.sql.DatabaseMetaData mtdt = c.getMetaData();
				System.out.println(mtdt.getDatabaseProductName());
				System.out.println(mtdt.getDatabaseProductVersion());
				System.out.println("Success!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
