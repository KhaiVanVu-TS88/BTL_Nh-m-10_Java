package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Luong {
	private String maLuong;
	private String maNhanVien;
	private String thoiGian;
	private int luongCoBan;
	private int phuCap;
	private int thuong;
	private int phat;
	private int thue;
	private int thucLanh;

	public Luong() {
		super();
	}

	public Luong(String maLuong, String maNhanVien, String thoiGian, int luongCoBan, int phuCap,
			int thuong, int phat, int thue, int thucLanh) {
		super();
		this.maLuong = maLuong;
		this.maNhanVien = maNhanVien;
		this.thoiGian = thoiGian;
		this.luongCoBan = luongCoBan;
		this.phuCap = phuCap;
		this.thuong = thuong;
		this.phat = phat;
		this.thue = thue;
		this.thucLanh = thucLanh;
	}
//	public Luong(String maLuong, String maNhanVien, String thoiGian, int luongCoBan, int phuCap,
//			int thuong, int phat, int thue) {
//		super();
//		this.maLuong = maLuong;
//		this.maNhanVien = maNhanVien;
//		this.thoiGian = thoiGian;
//		this.luongCoBan = luongCoBan;
//		this.phuCap = phuCap;
//		this.thuong = thuong;
//		this.phat = phat;
//		this.thue = thue;
//		this.thucLanh = luongCoBan + phuCap+thuong - phat-thue;
//	}

	public String getMaLuong() {
		return maLuong;
	}

	public void setMaLuong(String maLuong) {
		this.maLuong = maLuong;
	}

	public String getMaNhanVien() {
		return maNhanVien;
	}

	public void setMaNhanVien(String maNhanVien) {
		this.maNhanVien = maNhanVien;
	}

	public String getThoiGian() {
		return thoiGian;
	}

	public void setThoiGian(String thoiGian) {
		this.thoiGian = thoiGian;
	}

	public int getLuongCoBan() {
		return luongCoBan;
	}

	public void setLuongCoBan(int luongCoBan) {
		this.luongCoBan = luongCoBan;
	}

	public int getPhuCap() {
		return phuCap;
	}

	public void setPhuCap(int phuCap) {
		this.phuCap = phuCap;
	}

	public int getThuong() {
		return thuong;
	}

	public void setThuong(int thuong) {
		this.thuong = thuong;
	}

	public int getPhat() {
		return phat;
	}

	public void setPhat(int phat) {
		this.phat = phat;
	}

	public int getThue() {
		return thue;
	}

	public void setThue(int thue) {
		this.thue = thue;
	}

	public int getThucLanh() {
		return thucLanh;
	}

	public void setThucLanh(int thucLanh) {
		this.thucLanh = thucLanh;
	}

}
