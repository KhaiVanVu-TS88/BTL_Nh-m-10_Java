package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ChamCong {
	private String maChamCong;
	private String maNhanVien;
	private String thoiGian;
	private int ngayCong;
	private int soNgayNghi;
	private int gioLamThem;

	public ChamCong() {
		super();
	}

	public ChamCong(String maChamCong, String maNhanVien, String thoiGian, int ngayCong, int soNgayNghi,
			int gioLamThem) {
		super();
		this.maChamCong = maChamCong;
		this.maNhanVien = maNhanVien;
		this.thoiGian = thoiGian;
		this.ngayCong = ngayCong;
		this.soNgayNghi = soNgayNghi;
		this.gioLamThem = gioLamThem;
	}

	public String getMaChamCong() {
		return maChamCong;
	}

	public void setMaChamCong(String maChamCong) {
		this.maChamCong = maChamCong;
	}

	public String getMaNhanVien() {
		return maNhanVien;
	}

	public void setMaNhanVien(String maNhanVien) {
		this.maNhanVien = maNhanVien;
	}

	public String getThoiGian() {
		return thoiGian;
	}

	public void setThoiGian(String thoiGian) {
		this.thoiGian = thoiGian;
	}

	public int getNgayCong() {
		return ngayCong;
	}

	public void setNgayCong(int ngayCong) {
		this.ngayCong = ngayCong;
	}

	public int getSoNgayNghi() {
		return soNgayNghi;
	}

	public void setSoNgayNghi(int soNgayNghi) {
		this.soNgayNghi = soNgayNghi;
	}

	public int getGioLamThem() {
		return gioLamThem;
	}

	public void setGioLamThem(int gioLamThem) {
		this.gioLamThem = gioLamThem;
	}

	@Override
	public String toString() {
		return "ChamCong [maChamCong=" + maChamCong + ", maNhanVien=" + maNhanVien + ", thoiGian=" + thoiGian
				+ ", ngayCong=" + ngayCong + ", soNgayNghi=" + soNgayNghi + ", gioLamThem=" + gioLamThem + "]";
	}

}
