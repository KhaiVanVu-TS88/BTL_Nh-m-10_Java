package model;

import java.math.BigDecimal;

public class TuyenDung {
	private String maTuyenDung;
	private String hoTen;
	private String soDienThoai;
	private String email;
	private String chucVu;
	private String trinhDo;
	private int mucLuongDeal;
	private String trangThai;

	public TuyenDung() {
		super();
	}

	public TuyenDung(String maTuyenDung, String hoTen, String soDienThoai, String email, String chucVu, String trinhDo,
			int mucLuongDeal, String trangThai) {
		super();
		this.maTuyenDung = maTuyenDung;
		this.hoTen = hoTen;
		this.soDienThoai = soDienThoai;
		this.email = email;
		this.chucVu = chucVu;
		this.trinhDo = trinhDo;
		this.mucLuongDeal = mucLuongDeal;
		this.trangThai = trangThai;
	}

	public String getMaTuyenDung() {
		return maTuyenDung;
	}

	public void setMaTuyenDung(String maTuyenDung) {
		this.maTuyenDung = maTuyenDung;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public String getSoDienThoai() {
		return soDienThoai;
	}

	public void setSoDienThoai(String soDienThoai) {
		this.soDienThoai = soDienThoai;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getChucVu() {
		return chucVu;
	}

	public void setChucVu(String chucVu) {
		this.chucVu = chucVu;
	}

	public String getTrinhDo() {
		return trinhDo;
	}

	public void setTrinhDo(String trinhDo) {
		this.trinhDo = trinhDo;
	}

	public int getMucLuongDeal() {
		return mucLuongDeal;
	}

	public void setMucLuongDeal(int mucLuongDeal) {
		this.mucLuongDeal = mucLuongDeal;
	}

	public String getTrangThai() {
		return trangThai;
	}

	public void setTrangThai(String trangThai) {
		this.trangThai = trangThai;
	}

	@Override
	public String toString() {
		return "TuyenDung [maTuyenDung=" + maTuyenDung + ", hoTen=" + hoTen + ", soDienThoai=" + soDienThoai
				+ ", email=" + email + ", chucVu=" + chucVu + ", trinhDo=" + trinhDo + ", mucLuongDeal=" + mucLuongDeal
				+ ", trangThai=" + trangThai + "]";
	}
	
	

}
