package model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class PhongBan {
	private String maPhongBan;
	private String tenPhongBan;
	private String ngayThanhLap;
	private String truongPhong;
	private String ngayNhanChuc;
	private int soLuongNhanVien;
	private int luongTrungBinh;

	public PhongBan() {
		super();
	}

	public PhongBan(String maPhongBan, String tenPhongBan, String ngayThanhLap, String truongPhong,
			String ngayNhanChuc, int soLuongNhanVien, int luongTrungBinh) {
		super();
		this.maPhongBan = maPhongBan;
		this.tenPhongBan = tenPhongBan;
		this.ngayThanhLap = ngayThanhLap;
		this.truongPhong = truongPhong;
		this.ngayNhanChuc = ngayNhanChuc;
		this.soLuongNhanVien = soLuongNhanVien;
		this.luongTrungBinh = luongTrungBinh;
	}

	public String getMaPhongBan() {
		return maPhongBan;
	}

	public void setMaPhongBan(String maPhongBan) {
		this.maPhongBan = maPhongBan;
	}

	public String getTenPhongBan() {
		return tenPhongBan;
	}

	public void setTenPhongBan(String tenPhongBan) {
		this.tenPhongBan = tenPhongBan;
	}

	public String getNgayThanhLap() {
		return ngayThanhLap;
	}

	public void setNgayThanhLap(String ngayThanhLap) {
		this.ngayThanhLap = ngayThanhLap;
	}

	public String getTruongPhong() {
		return truongPhong;
	}

	public void setTruongPhong(String truongPhong) {
		this.truongPhong = truongPhong;
	}

	public String getNgayNhanChuc() {
		return ngayNhanChuc;
	}

	public void setNgayNhanChuc(String ngayNhanChuc) {
		this.ngayNhanChuc = ngayNhanChuc;
	}

	public int getSoLuongNhanVien() {
		return soLuongNhanVien;
	}

	public void setSoLuongNhanVien(int soLuongNhanVien) {
		this.soLuongNhanVien = soLuongNhanVien;
	}

	public int getLuongTrungBinh() {
		return luongTrungBinh;
	}

	public void setLuongTrungBinh(int luongTrungBinh) {
		this.luongTrungBinh = luongTrungBinh;
	}

}
