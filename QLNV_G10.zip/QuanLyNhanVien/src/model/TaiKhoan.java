package model;

public class TaiKhoan {
	private String maNhanVien;
	private String quyen;

	public TaiKhoan() {
		super();
	}

	public TaiKhoan(String maNhanVien, String quyen) {
		super();
		this.maNhanVien = maNhanVien;
		this.quyen = quyen;
	}

	public String getMaNhanVien() {
		return maNhanVien;
	}

	public void setMaNhanVien(String maNhanVien) {
		this.maNhanVien = maNhanVien;
	}

	public String getQuyen() {
		return quyen;
	}

	public void setQuyen(String quyen) {
		this.quyen = quyen;
	}

}
