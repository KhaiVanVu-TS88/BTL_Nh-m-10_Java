package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.Panel_TaiKhoanView;

public class Panel_TaiKhoanController implements ActionListener {

	private Panel_TaiKhoanView view;
	
	public Panel_TaiKhoanController(Panel_TaiKhoanView view) {
		this.view = view;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() ==view.getBtnThem()) {
			view.themTaiKhoan();
		}else if (e.getSource() ==view.getBtnSua()) {
			view.suaTaiKhoan();
		}else if (e.getSource() ==view.getBtnXoa()) {
			view.xoaTaiKhoan();
		}else if (e.getSource() ==view.getBtnRefresh()) {
			view.loadTaiKhoanData();
		}
	}

}
