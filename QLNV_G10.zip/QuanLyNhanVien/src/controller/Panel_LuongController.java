package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.Panel_LuongView;

public class Panel_LuongController implements ActionListener{

	private Panel_LuongView view;
	
	public Panel_LuongController(Panel_LuongView view) {
		// TODO Auto-generated constructor stub
		this.view = view;
	
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == view.getBtnSort()) {
			view.sortLuongData();
		}else if (e.getSource()==view.getBtnReverse()) {
			view.reverseTableData();
		}else if (e.getSource()==view.getBtnSearch()) {
			view.searchLuongData();
		}else if (e.getSource()==view.getBtnReset()) {
			view.resetSearch();
		}else if (e.getSource()==view.getBtnEditLuong()) {
			view.editLuong();
		}
	}

}
