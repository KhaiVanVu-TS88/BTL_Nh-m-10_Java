package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.Panel_TuyenDungView;

public class Panel_TuyenDungController implements ActionListener {
	private Panel_TuyenDungView view;

	public Panel_TuyenDungController(Panel_TuyenDungView view) {
		// TODO Auto-generated constructor stub
		this.view = view;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == view.getBtnThemNhanVien()) {
			view.them();
		} else if (e.getSource() == view.getBtnSua()) {
			view.sua();
		} else if (e.getSource() == view.getBtnXoa()) {
			view.xoa();
		} else if (e.getSource() == view.getBtnTuyn()) {
			view.tuyen();
		} else if (e.getSource() == view.getBtnTimKiem()) {
			view.tim();
		} else if (e.getSource() == view.getBtnRefresh()) {
			view.loadInternData();
		}

	}
}
