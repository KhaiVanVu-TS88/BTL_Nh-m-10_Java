package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;

import view.Panel_NhanVienView;
import view.ThemNV;

public class Panel_NhanVienController implements ActionListener {
	private Panel_NhanVienView view;

	public Panel_NhanVienController(Panel_NhanVienView view) {
		this.view = view;

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		// String s = e.getActionCommand();
		if (e.getSource() == view.getBtnThemNhanVien()) {
			view.themNV();
		} else if (e.getSource() == view.getBtnSua()) {
			view.suaNV();
		} else if (e.getSource() == view.getBtnXoa()) {
			view.xoaNV();
		} else if (e.getSource() == view.getBtnTimKiem()) {
			view.timNV();
		} else if (e.getSource() == view.getBtnRefresh()) {
			view.loadEmployeeData();
		}

	}
	
	//
}
