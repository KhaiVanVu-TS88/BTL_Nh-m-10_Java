package controller;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import view.ManHinhView;

public class ManHinhController {

	private ManHinhView manHinhView;

	public ManHinhController(ManHinhView manHinhView) {
		this.manHinhView = manHinhView;
		addEventListeners();
	}

	private void addEventListeners() {
		manHinhView.lbTrangChu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				manHinhView.showPanel("Trang Chủ");
			}
		});

		manHinhView.lbTuyenDung.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				manHinhView.showPanel("Tuyển Dụng");
			}
		});

		manHinhView.lbNhanVien.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				manHinhView.showPanel("Nhân Viên");
			}
		});

		manHinhView.lbChamCong.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				manHinhView.showPanel("Chấm công");
			}
		});

		manHinhView.lbPhongBan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				manHinhView.showPanel("Phòng ban");
			}
		});

		manHinhView.lbLuong.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				manHinhView.showPanel("Lương");
			}
		});

		manHinhView.lbTaiKhoan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				manHinhView.showPanel("Tài Khoản");
			}
		});

	}

}
