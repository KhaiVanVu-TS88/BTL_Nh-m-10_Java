package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.Panel_PhongBanView;

public class Panel_PhongBanController implements ActionListener{
	private Panel_PhongBanView view;
	
	public Panel_PhongBanController(Panel_PhongBanView view) {
		// TODO Auto-generated constructor stub
		this.view = view;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == view.getBtnThem()) {
			view.themPhongBan();
		} else if (e.getSource()== view.getBtnSua()) {
			view.suaPhongBan();
		}else if (e.getSource()==view.getBtnXoa()) {
			view.xoaPhongBan();
		} else if(e.getSource() == view.getBtnTimKiem()) {
			view.timPhongBan();
		}else if (e.getSource() == view.getBtnRefresh()) {
			view.loadPhongBanData();
		}
	}

}
