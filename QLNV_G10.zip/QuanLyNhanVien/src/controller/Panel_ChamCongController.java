package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.Panel_ChamCongView;

public class Panel_ChamCongController implements ActionListener{
	private Panel_ChamCongView view;
	
	public Panel_ChamCongController(Panel_ChamCongView view) {
		// TODO Auto-generated constructor stub
		this.view = view;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == view.getBtnAttendance()) {
			view.updateTableData("work");
		} else if (e.getSource() == view.getBtnLeave()) {
			view.updateTableData("leave");
		} else if (e.getSource() == view.getBtnOvertime()) {
			view.updateTableData("overtime");
		} else if (e.getSource() == view.getBtnRefresh()) {
			view.loadChamCongData();
		}
	}

}
