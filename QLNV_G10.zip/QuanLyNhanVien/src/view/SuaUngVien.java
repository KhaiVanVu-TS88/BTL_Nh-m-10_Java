package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.NhanVienDAO;
import dao.TuyenDungDAO;
import model.NhanVien;
import model.TuyenDung;

public class SuaUngVien extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTextField tfMaUngVien, tfTenUngVien, tfSoDienThoai, tfEmail, tfChucVu, tfTrinhDo, tfDealLuong;

    public SuaUngVien(TuyenDung updateTuyenDung) {
        this.setTitle("Sửa ứng viên");
        this.setLocation(100, 100);
        this.setSize(763, 334);
        getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 1, 746, 226);
        panel.setBackground(new Color(255, 255, 255));
        getContentPane().add(panel);
        panel.setLayout(new GridLayout(3, 6, 10, 50));

        // Mã ứng viên
        JLabel lbMaUngVien = new JLabel("Mã ứng viên:");
        lbMaUngVien.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMaUngVien);
        tfMaUngVien = new JTextField(updateTuyenDung.getMaTuyenDung());
        tfMaUngVien.setForeground(Color.GRAY);
        panel.add(tfMaUngVien);

        // Tên ứng viên
        JLabel lbHoTenUngVien = new JLabel("Họ tên ứng viên:");
        lbHoTenUngVien.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbHoTenUngVien);
        tfTenUngVien = new JTextField(updateTuyenDung.getHoTen());
        tfTenUngVien.setForeground(Color.GRAY);
        panel.add(tfTenUngVien);

        // số điện thoại
        JLabel lbSoDienThoai = new JLabel("Số điện thoại:");
        lbSoDienThoai.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbSoDienThoai);
        tfSoDienThoai = new JTextField(updateTuyenDung.getSoDienThoai());
        tfSoDienThoai.setForeground(Color.GRAY);
        panel.add(tfSoDienThoai);

        // email
        JLabel lbEmail = new JLabel("Email:");
        lbEmail.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbEmail);
        tfEmail = new JTextField(updateTuyenDung.getEmail());
        tfEmail.setForeground(Color.GRAY);
        panel.add(tfEmail);

        // chức vụ
        JLabel lbChucVu = new JLabel("Chức vụ:");
        lbChucVu.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbChucVu);
        tfChucVu = new JTextField(updateTuyenDung.getChucVu());
        tfChucVu.setForeground(Color.GRAY);
        panel.add(tfChucVu);

        // truinhf độ
        JLabel lbTrinhDo = new JLabel("Trình độ:");
        lbTrinhDo.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbTrinhDo);
        tfTrinhDo = new JTextField(updateTuyenDung.getTrinhDo());
        tfTrinhDo.setForeground(Color.GRAY);
        panel.add(tfTrinhDo);

        // deal lương
        JLabel lbMucLuongDeal = new JLabel("Mức lương Deal:");
        lbMucLuongDeal.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMucLuongDeal);
        tfDealLuong = new JTextField(String.valueOf(updateTuyenDung.getMucLuongDeal()));
        tfDealLuong.setForeground(Color.GRAY);
        panel.add(tfDealLuong);

        // trang thái
        JLabel lbTrangThai = new JLabel("Trạng thái:");
        lbTrangThai.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbTrangThai);
        
        JComboBox<String> cmbTrangThai = new JComboBox<>();
        
        //JComboBox cmbTrangThai = new JComboBox();
        cmbTrangThai.addItem(updateTuyenDung.getTrangThai());
        cmbTrangThai.setModel(new DefaultComboBoxModel(new String[] {"Tuyen", "Chua tuyen"}));
        panel.add(cmbTrangThai);

        // empty
        JLabel lbEmpty = new JLabel("");
        lbEmpty.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbEmpty);
        
        JLabel lbEmpty_1 = new JLabel("");
        lbEmpty_1.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbEmpty_1);

        // Button Sửa ứng viên
        JButton btnSuaUV = new JButton("Sửa ứng viên");
        btnSuaUV.setFont(new Font("Arial", Font.BOLD, 14));
        //btnThemNV.setBackground(new Color(0, 102, 204));
        btnSuaUV.setForeground(Color.WHITE);
        btnSuaUV.setBounds(275, 237, 200, 43);
        
        btnSuaUV.setBorderPainted(false);
        btnSuaUV.setBackground(Color.decode("#3498db"));
        btnSuaUV.setFocusPainted(false);
        btnSuaUV.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        getContentPane().add(btnSuaUV);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(255, 255, 255));
        panel_1.setBounds(0, 221, 746, 66);
        getContentPane().add(panel_1);

        // Xử lý sự kiện khi click vào nút "Thêm nhân viên"
        btnSuaUV.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lấy dữ liệu từ các trường nhập liệu

                
                 String maTuyenDung = tfMaUngVien.getText();
            	 String hoTen =tfTenUngVien.getText();
            	 String soDienThoai = tfSoDienThoai.getText();
            	 String email = tfEmail.getText();
            	 String chucVu = tfChucVu.getText();
            	 String trinhDo= tfTrinhDo.getText();
            	 int mucLuongDeal =Integer.parseInt(tfDealLuong.getText()) ;
            	 String trangThai=(String) cmbTrangThai.getSelectedItem();

                // Tạo đối tượng NhanVien và thêm vào cơ sở dữ liệu
                TuyenDung ungVien = new TuyenDung(maTuyenDung, hoTen, soDienThoai, email, chucVu, trinhDo, mucLuongDeal, trangThai);
                TuyenDungDAO tuyenDungDAO = TuyenDungDAO.getInstance();

                // Thực hiện thêm nhân viên vào cơ sở dữ liệu
                int result = tuyenDungDAO.update(ungVien);

                if (result > 0) {
                    JOptionPane.showMessageDialog(null, "Sửa ứng viên thành công!");
                } else {
                    JOptionPane.showMessageDialog(null, "Sửa ứng viên thất bại!");
                }
            }
        });
    }
}


