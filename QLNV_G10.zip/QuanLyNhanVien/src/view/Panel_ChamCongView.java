package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controller.Panel_ChamCongController;
import dao.ChamCongDAO;
import model.ChamCong;
import model.NhanVien;

import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;

public class Panel_ChamCongView extends Panel_ManHinh {
	private static LocalDate currentDate = LocalDate.now(); // Thời gian hiện tại
	private static int selectedRow = -1; // Dòng được chọn trong JTable
	private static JTable table;
	private static JPanel calendarPanel;
	private static JLabel[][] dayLabels = new JLabel[6][7]; // Ô lịch (tối đa 6 tuần)
	private static JButton btnAttendance, btnLeave, btnOvertime, btnRefresh;
	private static ChamCongDAO chamCongDAO;

	public Panel_ChamCongView() {
		chamCongDAO = new ChamCongDAO();
		setLayout(new BorderLayout());

		// Bảng dữ liệu
		JPanel tablePanel = createTablePanel();

		// Lịch hiển thị
		calendarPanel = createCalendarPanel();
		calendarPanel.setVisible(false); // Ẩn lịch lúc đầu

		// Footer: Chức năng chấm công
		JPanel footerPanel = createFooterPanel();

		// Layout chính
		add(tablePanel, BorderLayout.WEST);
		add(calendarPanel, BorderLayout.CENTER);
		add(footerPanel, BorderLayout.SOUTH);

		// Tạo Timer để kiểm tra và cập nhật lịch
		Timer timer = new Timer(1000, e -> {
			LocalDate now = LocalDate.now();
			if (now.getMonthValue() != currentDate.getMonthValue() || now.getYear() != currentDate.getYear()) {
				currentDate = now; // Cập nhật ngày hiện tại
				updateCalendarPanel(); // Làm mới giao diện lịch
			}
		});
		timer.start();

		// Controller
		Panel_ChamCongController ccc = new Panel_ChamCongController(this);

		btnAttendance.addActionListener(ccc);
		btnLeave.addActionListener(ccc);
		btnOvertime.addActionListener(ccc);
		btnRefresh.addActionListener(ccc);

	}

	// Tạo bảng dữ liệu
	private static JPanel createTablePanel() {
		JPanel panel = new JPanel(new BorderLayout());

		table = new JTable();
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Mã chấm công", "Mã nhân viên",
				"Thời gian", "Ngày công", "Ngày nghỉ", "Giờ làm thêm" }));
		table.setFont(new Font("Arial", Font.BOLD, 10));

		// Lắng nghe sự kiện chọn dòng
		table.getSelectionModel().addListSelectionListener(e -> {
			selectedRow = table.getSelectedRow();
			if (selectedRow != -1) {
				calendarPanel.setVisible(true); // Hiển thị lịch khi chọn dòng
				updateCalendarPanel(); // Cập nhật lịch
			}
		});

		panel.add(new JScrollPane(table), BorderLayout.CENTER);
		panel.setPreferredSize(new Dimension(400, 600));
		loadChamCongData();
		return panel;
	}

	// Tạo lịch tháng hiện tại
	private static JPanel createCalendarPanel() {
		JPanel panel = new JPanel(new BorderLayout());

		// Tiêu đề lịch
		JLabel title = new JLabel("", SwingConstants.CENTER);
		title.setFont(new Font("Arial", Font.BOLD, 18));
		panel.add(title, BorderLayout.NORTH);

		// Bảng lịch
		JPanel gridPanel = new JPanel(new GridLayout(6, 7));
		panel.add(gridPanel, BorderLayout.CENTER);

		String[] daysOfWeek = { "CN", "T2", "T3", "T4", "T5", "T6", "T7" };
		for (String day : daysOfWeek) {
			JLabel dayLabel = new JLabel(day, SwingConstants.CENTER);
			dayLabel.setFont(new Font("Arial", Font.BOLD, 14));
			gridPanel.add(dayLabel);
		}

		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				JLabel day = new JLabel("", SwingConstants.CENTER);
				day.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
				day.setFont(new Font("Arial", Font.PLAIN, 14));
				int finalI = i;
				int finalJ = j;

				// Sự kiện click vào ngày
				day.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						if (!day.getText().isEmpty()) {
							for (JLabel[] row : dayLabels) {
								for (JLabel cell : row) {
									cell.setBackground(null);
									cell.setOpaque(false);
								}
							}
							day.setOpaque(true);
							day.setBackground(Color.CYAN); // Đổi màu ô được chọn
						}
					}
				});

				dayLabels[i][j] = day;
				gridPanel.add(day);
			}
		}

		return panel;
	}

	// Footer: Chức năng chấm công
	private static JPanel createFooterPanel() {
		JPanel panel = new JPanel();

		btnAttendance = new JButton("Chấm công");
		btnLeave = new JButton("Nghỉ");
		btnOvertime = new JButton("Tăng ca");
		btnRefresh = new JButton("Refresh");

//        btnAttendance.addActionListener(e -> updateTableData("work"));
//        btnLeave.addActionListener(e -> updateTableData("leave"));
//        btnOvertime.addActionListener(e -> updateTableData("overtime"));
//        btnRefresh.addActionListener(e -> loadChamCongData());

		btnAttendance.setBorderPainted(false);
		btnAttendance.setBackground(Color.decode("#3498db"));
		btnAttendance.setFocusPainted(false);
		btnAttendance.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnAttendance.setForeground(Color.white);

		btnLeave.setBorderPainted(false);
		btnLeave.setBackground(Color.decode("#3498db"));
		btnLeave.setFocusPainted(false);
		btnLeave.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnLeave.setForeground(Color.white);

		btnOvertime.setBorderPainted(false);
		btnOvertime.setBackground(Color.decode("#3498db"));
		btnOvertime.setFocusPainted(false);
		btnOvertime.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnOvertime.setForeground(Color.white);

		btnRefresh.setBorderPainted(false);
		btnRefresh.setBackground(Color.decode("#3498db"));
		btnRefresh.setFocusPainted(false);
		btnRefresh.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnRefresh.setForeground(Color.white);

		panel.add(btnAttendance);
		panel.add(btnLeave);
		panel.add(btnOvertime);
		panel.add(btnRefresh);

		return panel;
	}

	// Cập nhật dữ liệu trong bảng
	public static void updateTableData(String action) {
		if (selectedRow == -1) {
			JOptionPane.showMessageDialog(null, "Hãy chọn một nhân viên trước!");
			return;
		}

		DefaultTableModel model = (DefaultTableModel) table.getModel();
		int currentValue;
		
		String maCC =(String) model.getValueAt(selectedRow, 0);
//		ChamCong chamCong = new ChamCong();
//		chamCong.setMaChamCong(maCC);
		
		switch (action) {
		case "work":
			ChamCong chamCong = new ChamCong();
			chamCong.setMaChamCong(maCC);
			currentValue = (int) model.getValueAt(selectedRow, 3); // Ngày công
			model.setValueAt(currentValue + 1, selectedRow, 3);
			chamCong.setNgayCong(currentValue+1);
			chamCongDAO.updateNgayCong(chamCong);
			break;
		case "leave":
			ChamCong chamCong2 = new ChamCong();
			chamCong2.setMaChamCong(maCC);
			currentValue = (int) model.getValueAt(selectedRow, 4); // Ngày nghỉ
			model.setValueAt(currentValue + 1, selectedRow, 4);
			chamCong2.setSoNgayNghi(currentValue+1);
			chamCongDAO.updateSoNgayNghi(chamCong2);
			break;
		case "overtime":
			ChamCong chamCong3 = new ChamCong();
			chamCong3.setMaChamCong(maCC);
			currentValue = (int) model.getValueAt(selectedRow, 5); // Giờ làm thêm
			model.setValueAt(currentValue + 1, selectedRow, 5);
			chamCong3.setGioLamThem(currentValue+1);
			chamCongDAO.updateGioLamThem(chamCong3);
			break;
		}
	}

	// Cập nhật giao diện lịch
	// Cập nhật giao diện lịch
	public static void updateCalendarPanel() {
		LocalDate firstDayOfMonth = LocalDate.of(currentDate.getYear(), currentDate.getMonthValue(), 1);
		int firstDayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7; // Chủ nhật là 0
		int daysInMonth = firstDayOfMonth.lengthOfMonth();

		int day = 1;
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				if (i == 0 && j < firstDayOfWeek || day > daysInMonth) {
					dayLabels[i][j].setText("");
					dayLabels[i][j].setOpaque(false); // Không tô màu
				} else {
					dayLabels[i][j].setText(String.valueOf(day));

					// Kiểm tra nếu ngày hiện tại
					if (day == currentDate.getDayOfMonth()
							&& currentDate.getMonthValue() == LocalDate.now().getMonthValue()
							&& currentDate.getYear() == LocalDate.now().getYear()) {
						dayLabels[i][j].setOpaque(true);
						dayLabels[i][j].setBackground(Color.LIGHT_GRAY); // Đổi màu nền
					} else {
						dayLabels[i][j].setOpaque(false);
						dayLabels[i][j].setBackground(null);
					}
					day++;
				}
			}
		}
	}

	// Tải dữ liệu chấm công từ cơ sở dữ liệu
	public static void loadChamCongData() {
		// Giả sử ChamCongDAO sẽ tải dữ liệu từ cơ sở dữ liệu
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0); // Xóa dữ liệu hiện tại

		for (ChamCong chamCong : chamCongDAO.selectALL()) {
			model.addRow(new Object[] { chamCong.getMaChamCong(), chamCong.getMaNhanVien(), chamCong.getThoiGian(),
					chamCong.getNgayCong(), chamCong.getSoNgayNghi(), chamCong.getGioLamThem() });
		}
	}

	public static JButton getBtnAttendance() {
		return btnAttendance;
	}

	public static void setBtnAttendance(JButton btnAttendance) {
		Panel_ChamCongView.btnAttendance = btnAttendance;
	}

	public static JButton getBtnLeave() {
		return btnLeave;
	}

	public static void setBtnLeave(JButton btnLeave) {
		Panel_ChamCongView.btnLeave = btnLeave;
	}

	public static JButton getBtnOvertime() {
		return btnOvertime;
	}

	public static void setBtnOvertime(JButton btnOvertime) {
		Panel_ChamCongView.btnOvertime = btnOvertime;
	}

	public static JButton getBtnRefresh() {
		return btnRefresh;
	}

	public static void setBtnRefresh(JButton btnRefresh) {
		Panel_ChamCongView.btnRefresh = btnRefresh;
	}
}
