package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.plot.PlotOrientation;

import dao.PhongBanDAO;
import model.PhongBan;

import java.awt.*;
import java.util.List;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Panel_TrangChuView extends Panel_ManHinh {

	private static final long serialVersionUID = 1L;
	private JTable table;
	private PhongBanDAO phongbanDAO;
	private Component barChartPanel;
	private ChartPanel pieChartPanel;

	public Panel_TrangChuView() {
		super();
		phongbanDAO = new PhongBanDAO();

		// Tạo và thêm biểu đồ cột
		barChartPanel = createChartPanel(createBarChart(createBarDataset()), 22, 10, 418, 300);
		add(barChartPanel);

		// Tạo và thêm biểu đồ tròn
		pieChartPanel = createChartPanel(createPieChart(createPieDataset()), 450, 10, 414, 300);
		add(pieChartPanel);

		// Tạo bảng và thêm vào JScrollPane
		JScrollPane scrollPane = createTableScrollPane();
		add(scrollPane);

		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadEmployeeData();
				// Tạo dataset mới
		        DefaultCategoryDataset newBarDataset = createBarDataset();
		        DefaultPieDataset newPieDataset = createPieDataset();

		        // Xóa biểu đồ cũ
		        remove(barChartPanel);
		        remove(pieChartPanel);

		        // Tạo lại biểu đồ mới
		        barChartPanel = createChartPanel(createBarChart(newBarDataset), 22, 10, 418, 300);
		        pieChartPanel = createChartPanel(createPieChart(newPieDataset), 450, 10, 414, 300);

		        // Thêm biểu đồ mới vào panel
		        add(barChartPanel);
		        add(pieChartPanel);

		        // Cập nhật giao diện
		        revalidate();
		        repaint();
			}
		});
		btnRefresh.setForeground(new Color(255, 255, 255));
		btnRefresh.setBounds(756, 604, 85, 21);
		btnRefresh.setBorderPainted(false);
		btnRefresh.setBackground(Color.decode("#3498db"));
		btnRefresh.setFocusPainted(false);
		btnRefresh.setCursor(new Cursor(Cursor.HAND_CURSOR));
		add(btnRefresh);

		loadEmployeeData(); // Tải dữ liệu bảng
	}

	
	
	// Phương thức tạo dataset cho biểu đồ cột
	private DefaultCategoryDataset createBarDataset() {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		List<PhongBan> phongBans = phongbanDAO.getPhongBanStatistics();
		for (PhongBan pb : phongBans) {
			dataset.addValue(pb.getLuongTrungBinh(), "Lương trung bình", pb.getTenPhongBan());
		}

		return dataset;
	}

	// Phương thức tạo dataset cho biểu đồ tròn
	private DefaultPieDataset createPieDataset() {
		DefaultPieDataset dataset = new DefaultPieDataset();

		List<PhongBan> phongBans = phongbanDAO.getPhongBanCount();
		for (PhongBan pb : phongBans) {
			dataset.setValue(pb.getTenPhongBan(), pb.getSoLuongNhanVien());
		}

		return dataset;
	}

	// Phương thức tạo biểu đồ cột
	private JFreeChart createBarChart(DefaultCategoryDataset dataset) {
		return ChartFactory.createBarChart("Thống kê gần đây", // Tên biểu đồ
				"Phòng", // Tên trục X
				"Giá trị (triệu)", // Tên trục Y
				dataset, // Dữ liệu
				PlotOrientation.VERTICAL, // Hướng của biểu đồ
				true, // Hiển thị tiêu đề
				true, // Hiển thị các tooltip
				false // Không hiển thị URL
		);
	}

	// Phương thức tạo biểu đồ tròn
	private JFreeChart createPieChart(DefaultPieDataset dataset) {
		return ChartFactory.createPieChart("Tỷ lệ phòng ban", // Tên biểu đồ
				dataset, // Dữ liệu
				true, // Hiển thị các chú thích
				true, // Hiển thị phần trăm
				false // Không hiển thị URL
		);
	}

	// Phương thức tạo panel chứa biểu đồ với các thông số vị trí và kích thước
	private ChartPanel createChartPanel(JFreeChart chart, int x, int y, int width, int height) {
		ChartPanel chartPanel = new ChartPanel(chart);
		chartPanel.setBounds(x, y, width, height); // Cài đặt vị trí và kích thước của biểu đồ
		return chartPanel;
	}

	// Phương thức tạo bảng và đặt nó trong JScrollPane
	private JScrollPane createTableScrollPane() {
		// Tạo panel chứa tiêu đề "Thông tin tổng quan"
		JLabel titleLabel = new JLabel("Thông tin tổng quan", JLabel.CENTER);
		titleLabel.setFont(new Font("Roboto", Font.BOLD, 18)); // Sử dụng font đẹp và hiện đại
		titleLabel.setForeground(new Color(34, 45, 55)); // Màu xám đậm cho tiêu đề
		titleLabel.setBackground(new Color(200, 220, 240)); // Nền sáng và dễ nhìn
		titleLabel.setOpaque(true); // Đảm bảo nền màu xám sáng được hiển thị
		titleLabel.setBounds(22, 320, 842, 30); // Cập nhật vị trí cho tiêu đề

		add(titleLabel); // Thêm tiêu đề vào panel

		// Tạo JScrollPane
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 349, 842, 245); // Vị trí của bảng

		table = new JTable();
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Số thứ tự", "Tên phòng ban",
				"Ngày thành lập", "Trưởng phòng", "Ngày nhận chức", "Số lượng nhân viên", "Lương trung bình" }) {
			// Override phương thức để thêm Số thứ tự tự động
			@Override
			public boolean isCellEditable(int row, int column) {
				return false; // Không cho phép chỉnh sửa bảng
			}

			@Override
			public Object getValueAt(int row, int column) {
				if (column == 0) {
					return row + 1; // Cột số thứ tự tự động đánh số
				}
				return super.getValueAt(row, column);
			}
		});

		// Cập nhật giao diện cho bảng
		table.setFont(new Font("Roboto", Font.PLAIN, 12)); // Font chữ đẹp và mượt mà
		table.setForeground(new Color(0, 0, 0)); // Màu chữ đen dễ đọc
		table.setBackground(new Color(255, 255, 255)); // Nền trắng sạch sẽ
		table.setSelectionBackground(new Color(100, 150, 255)); // Màu nền khi chọn dòng
		table.setSelectionForeground(new Color(255, 255, 255)); // Màu chữ khi chọn dòng

		// Thêm hiệu ứng hover
		table.setRowHeight(30); // Điều chỉnh chiều cao dòng cho đẹp mắt
		table.setShowGrid(false); // Tắt lưới trong bảng để có cảm giác hiện đại hơn
		table.setIntercellSpacing(new Dimension(0, 0)); // Giảm khoảng cách giữa các ô trong bảng

		scrollPane.setViewportView(table);

		add(scrollPane); // Thêm bảng vào panel

		return scrollPane;
	}

	// Phương thức tải dữ liệu nhân viên vào bảng
	private void loadEmployeeData() {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		for (PhongBan pb : phongbanDAO.selectALL()) {
			model.addRow(new Object[] { pb.getMaPhongBan(), pb.getTenPhongBan(), pb.getNgayThanhLap(),
					pb.getTruongPhong(), pb.getNgayNhanChuc(), pb.getSoLuongNhanVien(), pb.getLuongTrungBinh() });
		}
	}
}
