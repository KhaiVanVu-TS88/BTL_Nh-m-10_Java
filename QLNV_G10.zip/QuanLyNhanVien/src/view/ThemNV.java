package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.NhanVienDAO;
import model.NhanVien;

public class ThemNV extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTextField tfMaNhanVien, tfTenNhanVien, tfGioiTinh, tfNgaySinh, tfDiaChi, tfSoDienThoai, tfMaPhongBan, tfChucVu, tfMucLuong;

    public ThemNV() {
        this.setTitle("Thêm nhân viên");
        this.setLocation(100, 100);
        this.setSize(763, 334);
        getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 1, 746, 226);
        panel.setBackground(new Color(255, 255, 255));
        getContentPane().add(panel);
        panel.setLayout(new GridLayout(3, 6, 10, 50));

        // Mã nhân viên
        JLabel lbMaNhanVien = new JLabel("Mã nhân viên:");
        lbMaNhanVien.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMaNhanVien);
        tfMaNhanVien = new JTextField();
        panel.add(tfMaNhanVien);

        // Tên nhân viên
        JLabel lbTenNhanVien = new JLabel("Tên nhân viên:");
        lbTenNhanVien.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbTenNhanVien);
        tfTenNhanVien = new JTextField();
        panel.add(tfTenNhanVien);

        // Giới tính
        JLabel lbGioiTinh = new JLabel("Giới tính:");
        lbGioiTinh.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbGioiTinh);
        tfGioiTinh = new JTextField();
        panel.add(tfGioiTinh);

        // Ngày sinh
        JLabel lbNgaySinh = new JLabel("Ngày sinh:");
        lbNgaySinh.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbNgaySinh);
        tfNgaySinh = new JTextField();
        panel.add(tfNgaySinh);

        // Địa chỉ
        JLabel lbDiaChi = new JLabel("Địa chỉ:");
        lbDiaChi.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbDiaChi);
        tfDiaChi = new JTextField();
        panel.add(tfDiaChi);

        // Số điện thoại
        JLabel lbSDT = new JLabel("Số điện thoại:");
        lbSDT.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbSDT);
        tfSoDienThoai = new JTextField();
        panel.add(tfSoDienThoai);

        // Mã phòng ban
        JLabel lbMaPhongBan = new JLabel("Mã phòng ban:");
        lbMaPhongBan.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMaPhongBan);
        tfMaPhongBan = new JTextField();
        panel.add(tfMaPhongBan);

        // Chức vụ
        JLabel lbChucVu = new JLabel("Chức vụ:");
        lbChucVu.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbChucVu);
        tfChucVu = new JTextField();
        panel.add(tfChucVu);

        // Mức lương
        JLabel lbMucLuong = new JLabel("Mức lương:");
        lbMucLuong.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMucLuong);
        tfMucLuong = new JTextField();
        panel.add(tfMucLuong);

        // Button Thêm nhân viên
        JButton btnThemNV = new JButton("Thêm nhân viên");
        btnThemNV.setFont(new Font("Arial", Font.BOLD, 14));
        //btnThemNV.setBackground(new Color(0, 102, 204));
        btnThemNV.setForeground(Color.WHITE);
        btnThemNV.setBounds(275, 237, 200, 43);
        
        btnThemNV.setBorderPainted(false);
        btnThemNV.setBackground(Color.decode("#3498db"));
        btnThemNV.setFocusPainted(false);
        btnThemNV.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        getContentPane().add(btnThemNV);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(255, 255, 255));
        panel_1.setBounds(0, 221, 746, 66);
        getContentPane().add(panel_1);

        // Xử lý sự kiện khi click vào nút "Thêm nhân viên"
        btnThemNV.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lấy dữ liệu từ các trường nhập liệu
                String maNhanVien = tfMaNhanVien.getText();
                String tenNhanVien = tfTenNhanVien.getText();
                String gioiTinh = tfGioiTinh.getText();
                String ngaySinh = tfNgaySinh.getText();
                String diaChi = tfDiaChi.getText();
                String soDienThoai = tfSoDienThoai.getText();
                String maPhongBan = tfMaPhongBan.getText();
                String chucVu = tfChucVu.getText();
                int mucLuong = Integer.parseInt(tfMucLuong.getText());

                // Tạo đối tượng NhanVien và thêm vào cơ sở dữ liệu
                NhanVien nhanVien = new NhanVien(maNhanVien, tenNhanVien, gioiTinh, ngaySinh, diaChi, soDienThoai, maPhongBan, chucVu, mucLuong);
                NhanVienDAO nhanVienDAO = NhanVienDAO.getInstance();

                // Thực hiện thêm nhân viên vào cơ sở dữ liệu
                int result = nhanVienDAO.insert(nhanVien);

                if (result > 0) {
                    JOptionPane.showMessageDialog(null, "Thêm nhân viên thành công!");
                } else {
                    JOptionPane.showMessageDialog(null, "Thêm nhân viên thất bại!");
                }
            }
        });
    }
}


