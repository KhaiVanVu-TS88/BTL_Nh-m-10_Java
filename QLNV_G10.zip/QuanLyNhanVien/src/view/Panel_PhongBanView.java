package view;

import dao.PhongBanDAO;
import model.PhongBan;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.Panel_PhongBanController;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Panel_PhongBanView extends Panel_ManHinh {

    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtMaPhongBan, txtTenPhongBan, txtNgayThanhLap, txtTruongPhong, txtNgayNhanChuc, txtSoLuongNhanVien, txtLuongTrungBinh;
    private JButton btnThem, btnSua, btnXoa, btnTimKiem;
    private PhongBanDAO phongBanDAO;
    private JButton btnRefresh;

    public Panel_PhongBanView() {
        super();
        phongBanDAO = PhongBanDAO.getInstance();
        setLayout(new BorderLayout());

        // Initialize Table
        tableModel = new DefaultTableModel(new Object[]{"Mã Phòng Ban", "Tên Phòng Ban", "Ngày Thành Lập", "Trưởng Phòng", "Ngày Nhận Chức", "Số Lượng Nhân Viên", "Lương Trung Bình"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Panel for input fields with padding
        JPanel inputPanel = createInputPanel();
        inputPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding around the input fields

        // Panel for buttons
        JPanel buttonPanel = createButtonPanel();

        // Add components to main panel with spacing between table and text fields
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(inputPanel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);  // Use centerPanel to include both inputPanel and scrollPane
        add(buttonPanel, BorderLayout.SOUTH);

        // Load existing data from DAO
        loadPhongBanData();

        Panel_PhongBanController pbc = new Panel_PhongBanController(this);
        
        btnThem.addActionListener(pbc);
        btnSua.addActionListener(pbc);
        btnXoa.addActionListener(pbc);
        btnTimKiem.addActionListener(pbc);
        btnRefresh.addActionListener(pbc);
        
        // Set button actions using lambda expressions
//        btnThem.addActionListener(e -> themPhongBan());
//        btnSua.addActionListener(e -> suaPhongBan());
//        btnXoa.addActionListener(e -> xoaPhongBan());
//        btnTimKiem.addActionListener(e -> timPhongBan());
//        btnRefresh.addActionListener(e -> loadPhongBanData());
    }

    // Creates input panel with fields
  private JPanel createInputPanel() {
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(7, 2, 10, 10)); // 7 rows, 2 columns, with gap of 10px

        inputPanel.add(new JLabel("Mã Phòng Ban:"));
        txtMaPhongBan = new JTextField();
        inputPanel.add(txtMaPhongBan);

        inputPanel.add(new JLabel("Tên Phòng Ban:"));
        txtTenPhongBan = new JTextField();
        inputPanel.add(txtTenPhongBan);

        inputPanel.add(new JLabel("Ngày Thành Lập:"));
        txtNgayThanhLap = new JTextField();
        inputPanel.add(txtNgayThanhLap);

        inputPanel.add(new JLabel("Trưởng Phòng:"));
        txtTruongPhong = new JTextField();
        inputPanel.add(txtTruongPhong);

        inputPanel.add(new JLabel("Ngày Nhận Chức:"));
        txtNgayNhanChuc = new JTextField();
        inputPanel.add(txtNgayNhanChuc);

        inputPanel.add(new JLabel("Số Lượng Nhân Viên:"));
        txtSoLuongNhanVien = new JTextField();
        inputPanel.add(txtSoLuongNhanVien);

        inputPanel.add(new JLabel("Lương Trung Bình:"));
        txtLuongTrungBinh = new JTextField();
        inputPanel.add(txtLuongTrungBinh);

        return inputPanel;
    }

    // Creates the button panel
    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        btnThem = new JButton("Thêm");
        btnThem.setBorderPainted(false);
        btnThem.setBackground(Color.decode("#3498db"));
        btnThem.setFocusPainted(false);
        btnThem.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnThem.setForeground(Color.white);
        btnSua = new JButton("Sửa");
        btnSua.setBorderPainted(false);
        btnSua.setBackground(Color.decode("#3498db"));
        btnSua.setFocusPainted(false);
        btnSua.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSua.setForeground(Color.white);

        btnXoa = new JButton("Xóa");
        btnXoa.setBorderPainted(false);
        btnXoa.setBackground(Color.decode("#e74c3c"));
        btnXoa.setFocusPainted(false);
        btnXoa.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnXoa.setForeground(Color.white);

        btnTimKiem = new JButton("Tìm Phòng Ban"); // Thêm nút Tìm Phòng Ban
        btnTimKiem.setBorderPainted(false);
        btnTimKiem.setBackground(Color.decode("#3498db"));
        btnTimKiem.setFocusPainted(false);
        btnTimKiem.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnTimKiem.setForeground(Color.white);
        
        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        buttonPanel.add(btnTimKiem);
        
        
        
        btnRefresh = new JButton("Refresh");
//        btnRefresh.addActionListener(new ActionListener() {
//        	public void actionPerformed(ActionEvent e) {
//        		loadPhongBanData();
//        	}
//        });
        btnRefresh.setForeground(Color.white);
        btnRefresh.setBorderPainted(false);
        btnRefresh.setBackground(Color.decode("#3498db"));
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(new Cursor(Cursor.HAND_CURSOR));
        buttonPanel.add(btnRefresh);
        return buttonPanel;
    }

    // Add new department
    public void themPhongBan() {
        if (validateInput()) {
            String maPB = txtMaPhongBan.getText();
            String tenPB = txtTenPhongBan.getText();
            String ngayTL = txtNgayThanhLap.getText();
            String truongPhong = txtTruongPhong.getText();
            String ngayNC = txtNgayNhanChuc.getText();
            int soLuongNV = Integer.parseInt(txtSoLuongNhanVien.getText());
            int luongTB = Integer.parseInt(txtLuongTrungBinh.getText());

            // Create PhongBan object
            PhongBan phongBan = new PhongBan(maPB, tenPB, ngayTL, truongPhong, ngayNC, soLuongNV, luongTB);

            // Add to database
            int result = phongBanDAO.insert(phongBan);

            if (result > 0) {
                // Add to tableModel to display
                Object[] row = {maPB, tenPB, ngayTL, truongPhong, ngayNC, soLuongNV, luongTB};
                tableModel.addRow(row);
                JOptionPane.showMessageDialog(this, "Thêm thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Thêm thất bại!");
            }
        }
    }

    // Edit department
    public void suaPhongBan() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String maPB = txtMaPhongBan.getText();
            String tenPB = txtTenPhongBan.getText();
            String ngayTL = txtNgayThanhLap.getText();
            String truongPhong = txtTruongPhong.getText();
            String ngayNC = txtNgayNhanChuc.getText();
            int soLuongNV = Integer.parseInt(txtSoLuongNhanVien.getText());
            int luongTB = Integer.parseInt(txtLuongTrungBinh.getText());

            // Create PhongBan object
            PhongBan phongBan = new PhongBan(maPB, tenPB, ngayTL, truongPhong, ngayNC, soLuongNV, luongTB);

            // Update in database
            int result = phongBanDAO.update(phongBan);

            if (result > 0) {
                // Update in tableModel
                tableModel.setValueAt(maPB, selectedRow, 0);
                tableModel.setValueAt(tenPB, selectedRow, 1);
                tableModel.setValueAt(ngayTL, selectedRow, 2);
                tableModel.setValueAt(truongPhong, selectedRow, 3);
                tableModel.setValueAt(ngayNC, selectedRow, 4);
                tableModel.setValueAt(soLuongNV, selectedRow, 5);
                tableModel.setValueAt(luongTB, selectedRow, 6);
                JOptionPane.showMessageDialog(this, "Sửa thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Sửa thất bại!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng ban cần sửa.");
        }
    }

    // Delete department
    public void xoaPhongBan() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa không?", "Xác nhận", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                // Lấy mã phòng ban của hàng được chọn
                String maPB = tableModel.getValueAt(selectedRow, 0).toString();

                // Tạo đối tượng phòng ban để xóa
                PhongBan phongBan = new PhongBan();
                phongBan.setMaPhongBan(maPB);

                // Xóa khỏi cơ sở dữ liệu
                int result = PhongBanDAO.getInstance().delete(phongBan);

                if (result > 0) {
                    // Xóa khỏi tableModel
                    tableModel.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(this, "Xóa thành công!");
                } else {
                    JOptionPane.showMessageDialog(this, "Xóa thất bại! Không tìm thấy phòng ban.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng ban cần xóa.");
        }
    }
    public void timPhongBan() {
        String maPB = txtMaPhongBan.getText();
        if (maPB.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã Phòng Ban cần tìm.");
            return;
        }

        PhongBan phongBan = new PhongBan();
        phongBan.setMaPhongBan(maPB);
        PhongBan ketQua = phongBanDAO.selectById(phongBan);

        if (ketQua != null) {
            tableModel.setRowCount(0); // Xóa dữ liệu hiện có trong bảng
            tableModel.addRow(new Object[]{
                ketQua.getMaPhongBan(), ketQua.getTenPhongBan(), ketQua.getNgayThanhLap(),
                ketQua.getTruongPhong(), ketQua.getNgayNhanChuc(), ketQua.getSoLuongNhanVien(), ketQua.getLuongTrungBinh()
            });
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy phòng ban có Mã: " + maPB);
        }
    }
    // Validate input fields for empty data
    public boolean validateInput() {
        if (txtMaPhongBan.getText().isEmpty() || txtTenPhongBan.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mã phòng ban và Tên phòng ban không được để trống.");
            return false;
        }
        return true;
    }

    // Load department data from DAO
    public void loadPhongBanData() {
    	DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Clear old data
        for (PhongBan pb : phongBanDAO.selectALL()) {
        	model.addRow(new Object[]{
                pb.getMaPhongBan(), pb.getTenPhongBan(), pb.getNgayThanhLap(),
                pb.getTruongPhong(), pb.getNgayNhanChuc(), pb.getSoLuongNhanVien(), pb.getLuongTrungBinh()
            });
        }
    }

	public JButton getBtnThem() {
		return btnThem;
	}

	public void setBtnThem(JButton btnThem) {
		this.btnThem = btnThem;
	}

	public JButton getBtnSua() {
		return btnSua;
	}

	public void setBtnSua(JButton btnSua) {
		this.btnSua = btnSua;
	}

	public JButton getBtnXoa() {
		return btnXoa;
	}

	public void setBtnXoa(JButton btnXoa) {
		this.btnXoa = btnXoa;
	}

	public JButton getBtnTimKiem() {
		return btnTimKiem;
	}

	public void setBtnTimKiem(JButton btnTimKiem) {
		this.btnTimKiem = btnTimKiem;
	}

	public JButton getBtnRefresh() {
		return btnRefresh;
	}

	public void setBtnRefresh(JButton btnRefresh) {
		this.btnRefresh = btnRefresh;
	}


    
    
}