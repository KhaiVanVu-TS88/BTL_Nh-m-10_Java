package view;

import model.NhanVien;
import model.PhongBan;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controller.Panel_NhanVienController;
import dao.NhanVienDAO;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Panel_NhanVienView extends Panel_ManHinh {

	private static final long serialVersionUID = 1L;
	private JTextField txtTimKiem;
	private DefaultTableModel tableModel;
	private JTable table;
	private JLabel lbMaNhanVienTT, lbTenNhanVien1, lbGioiTinh1, lbNgaySinh1, lbDiaChi1, lbSDT1, lbMaPhongBan1,
			lbChucVu1, lbMucLuong1;
	private NhanVienDAO nhanVienDAO;
	private JButton btnThemNhanVien;
	private JButton btnTimKiem;
	private JButton btnSua;
	private JButton btnXoa;
	private JButton btnRefresh;

	public Panel_NhanVienView() {
		super();
		nhanVienDAO = new NhanVienDAO();
		setLayout(null);

		JPanel panel_Title = new JPanel();
		panel_Title.setBounds(0, 0, 874, 74);
		panel_Title.setBackground(new Color(255, 255, 255));
		add(panel_Title);
		panel_Title.setLayout(null);

		JLabel lblNewLabel = new JLabel("Danh sách nhân viên");
		lblNewLabel.setForeground(Color.GRAY);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16));
		lblNewLabel.setBounds(24, 20, 169, 33);
		panel_Title.add(lblNewLabel);

		txtTimKiem = new JTextField();
		txtTimKiem.setForeground(Color.GRAY);
		txtTimKiem.setText("Tìm kiếm theo mã");
		txtTimKiem.setFont(new Font("Arial", Font.PLAIN, 13));
		txtTimKiem.setBounds(310, 22, 163, 33);
		panel_Title.add(txtTimKiem);
		txtTimKiem.setColumns(10);

		Panel_NhanVienController nvc = new Panel_NhanVienController(this);

		btnTimKiem = new JButton("");
		btnTimKiem.setIcon(new ImageIcon(Panel_NhanVienView.class.getResource("/img_btn/pngegg.png")));
		btnTimKiem.setFont(new Font("Arial", Font.BOLD, 16));
		btnTimKiem.setBounds(276, 22, 33, 33);
		btnTimKiem.setBorderPainted(false);
		btnTimKiem.setBackground(Color.decode("#3498db"));
		btnTimKiem.setFocusPainted(false);
		btnTimKiem.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnTimKiem.addActionListener(nvc);
		panel_Title.add(btnTimKiem);

		btnThemNhanVien = new JButton("Thêm");
		btnThemNhanVien.setIcon(new ImageIcon(Panel_NhanVienView.class.getResource("/img_btn/add3.png")));
		btnThemNhanVien.setForeground(Color.WHITE);
		btnThemNhanVien.setFont(new Font("Arial", Font.BOLD, 16));
		btnThemNhanVien.setBounds(530, 22, 104, 33);
		btnThemNhanVien.setBorderPainted(false);
		btnThemNhanVien.setBackground(Color.decode("#3498db"));
		btnThemNhanVien.setFocusPainted(false);
		btnThemNhanVien.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnThemNhanVien.addActionListener(nvc);
		panel_Title.add(btnThemNhanVien);

		btnSua = new JButton("Sửa");
		btnSua.setIcon(new ImageIcon(Panel_NhanVienView.class.getResource("/img_btn/Edit--Streamline-Unicons.png")));
		btnSua.setForeground(Color.WHITE);
		btnSua.setFont(new Font("Arial", Font.BOLD, 16));
		btnSua.setBounds(644, 22, 93, 33);
		btnSua.setBorderPainted(false);
		btnSua.setBackground(Color.decode("#3498db"));
		btnSua.setFocusPainted(false);
		btnSua.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnSua.addActionListener(nvc);
		panel_Title.add(btnSua);

		btnXoa = new JButton("Xóa");
		btnXoa.setIcon(new ImageIcon(Panel_NhanVienView.class.getResource("/img_btn/delete.png")));
		btnXoa.setForeground(Color.WHITE);
		btnXoa.setFont(new Font("Arial", Font.BOLD, 16));
		btnXoa.setBounds(747, 22, 93, 33);
		btnXoa.setBorderPainted(false);
		btnXoa.setBackground(new Color(253, 56, 21));
		btnXoa.setFocusPainted(false);
		btnXoa.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnXoa.addActionListener(nvc);
		panel_Title.add(btnXoa);

		btnRefresh = new JButton("");
		btnRefresh.setIcon(new ImageIcon(Panel_NhanVienView.class.getResource("/img_btn/icons8-refresh-16.png")));
		btnRefresh.setFont(new Font("Arial", Font.BOLD, 16));
		btnRefresh.setFocusPainted(false);
		btnRefresh.setBorderPainted(false);
		btnRefresh.setBackground(new Color(52, 152, 219));
		btnRefresh.setBounds(473, 22, 33, 33);
		btnRefresh.addActionListener(nvc);
		panel_Title.add(btnRefresh);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 84, 874, 313);
		add(scrollPane);

//		table = new JTable();
//		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Mã nhân viên", "Tên nhân viên",
//				"Giới tính", "Ngày sinh", "Địa chỉ", "Số điện thoại", "Mã phòng ban", "Chức vụ", "Mức lương" }));
//		table.setFont(new Font("Arial", Font.BOLD, 10));

		tableModel = new DefaultTableModel(new Object[][] {}, new String[] { "Mã nhân viên", "Tên nhân viên",
				"Giới tính", "Ngày sinh", "Địa chỉ", "Số điện thoại", "Mã phòng ban", "Chức vụ", "Mức lương" });
		table = new JTable(tableModel);
		table.setFont(new Font("Arial", Font.BOLD, 10));
		scrollPane.setViewportView(table);

		JPanel panel_TTNhanVien = new JPanel();
		panel_TTNhanVien.setBackground(Color.WHITE);
		panel_TTNhanVien.setBounds(0, 407, 874, 222);
		add(panel_TTNhanVien);
		panel_TTNhanVien.setLayout(new GridLayout(0, 6, 1, 1));

		JLabel lbMaNhanVien = new JLabel("Mã nhân viên:");
		panel_TTNhanVien.add(lbMaNhanVien);

		JLabel lbMaNhanVienTT = new JLabel("------------");// hiển thị mã nhân viên của nhân viên đang được click
		panel_TTNhanVien.add(lbMaNhanVienTT);

		JLabel lbTenNhanVien = new JLabel("Tên nhân viên:");
		panel_TTNhanVien.add(lbTenNhanVien);

		JLabel lbTenNhanVien1 = new JLabel("------------");// hiển thị tên nhân viên của nhân viên đang được click
		panel_TTNhanVien.add(lbTenNhanVien1);

		JLabel lbGioiTinh = new JLabel("Giới tính:");
		panel_TTNhanVien.add(lbGioiTinh);

		JLabel lbGioiTinh1 = new JLabel("------------");// hiển thị giới tính nhân viên của nhân viên đang được click
		panel_TTNhanVien.add(lbGioiTinh1);

		JLabel lbNgaySinh = new JLabel("Ngày sinh:");
		panel_TTNhanVien.add(lbNgaySinh);

		JLabel lbNgaySinh1 = new JLabel("------------");// hiển thị ngày sinh nhân viên của nhân viên đang được click
		panel_TTNhanVien.add(lbNgaySinh1);

		JLabel lbDiaChi = new JLabel("Địa chỉ:");
		panel_TTNhanVien.add(lbDiaChi);

		JLabel lbDiaChi1 = new JLabel("------------");// hiển thị địa chỉ nhân viên của nhân viên đang được click
		panel_TTNhanVien.add(lbDiaChi1);

		JLabel lbSDT = new JLabel("Số điện thoại:");
		panel_TTNhanVien.add(lbSDT);

		JLabel lbSDT1 = new JLabel("------------");// hiển thị số điện thoại nhân viên của nhân viên đang được click
		panel_TTNhanVien.add(lbSDT1);

		JLabel lbMaPhongBan = new JLabel("Mã phòng ban:");
		panel_TTNhanVien.add(lbMaPhongBan);

		JLabel lbMaPhongBan1 = new JLabel("------------");// hiển thị mã phòng ban của nhân viên của nhân viên đang được
															// click
		panel_TTNhanVien.add(lbMaPhongBan1);

		JLabel lbChucVu = new JLabel("Chức vụ:");
		panel_TTNhanVien.add(lbChucVu);

		JLabel lbChucVu1 = new JLabel("------------");// hiển thị chức vụ nhân viên của nhân viên đang được click
		panel_TTNhanVien.add(lbChucVu1);

		JLabel lbMucLuong = new JLabel("Mức lương:");
		panel_TTNhanVien.add(lbMucLuong);

		JLabel lbMucLuong1 = new JLabel("------------");// hiển thị mức lương nhân viên của nhân viên đang được click
		panel_TTNhanVien.add(lbMucLuong1);

		loadEmployeeData();

		// Add event listeners
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int selectedRow = table.getSelectedRow();
				if (selectedRow != -1) {
					lbMaNhanVienTT.setText((String) table.getValueAt(selectedRow, 0));
					lbTenNhanVien1.setText((String) table.getValueAt(selectedRow, 1));
					lbGioiTinh1.setText((String) table.getValueAt(selectedRow, 2));
					lbNgaySinh1.setText((String) table.getValueAt(selectedRow, 3));
					lbDiaChi1.setText((String) table.getValueAt(selectedRow, 4));
					lbSDT1.setText((String) table.getValueAt(selectedRow, 5));
					lbMaPhongBan1.setText((String) table.getValueAt(selectedRow, 6));
					lbChucVu1.setText((String) table.getValueAt(selectedRow, 7));
					lbMucLuong1.setText(String.valueOf(table.getValueAt(selectedRow, 8)));
				}
			}
		});

//		btnThemNhanVien.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				ThemNV tnv = new ThemNV();
//				tnv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//				tnv.setVisible(true);
//				// Cập nhật lại dữ liệu sau khi thêm thành công
//				tnv.addWindowListener(new java.awt.event.WindowAdapter() {
//					public void windowClosed(java.awt.event.WindowEvent windowEvent) {
//
//						loadEmployeeData(); // Tải lại dữ liệu
//					}
//				});
//			}
//		});

//		btnSua.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				int selectedRow = table.getSelectedRow();
//				if (selectedRow != -1) {
//					String maNV = (String) table.getValueAt(selectedRow, 0);
//					String tenNV = (String) table.getValueAt(selectedRow, 1);
//					String gioiTinh = (String) table.getValueAt(selectedRow, 2);
//					String ngaySinh = (String) table.getValueAt(selectedRow, 3);
//					String diaChi = (String) table.getValueAt(selectedRow, 4);
//					String sDTNV = (String) table.getValueAt(selectedRow, 5);
//					String maPhongBanNV = (String) table.getValueAt(selectedRow, 6);
//					String maChucVuNV = (String) table.getValueAt(selectedRow, 7);
//					int mucLuong = Integer.parseInt(String.valueOf(table.getValueAt(selectedRow, 8)));
//
//					NhanVien nhanvien = new NhanVien(maNV, tenNV, gioiTinh, ngaySinh, diaChi, sDTNV, maPhongBanNV,
//							maChucVuNV, mucLuong);
//
//					SuaNV snv = new SuaNV(nhanvien);
//					snv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//					snv.setVisible(true);
//					// Cập nhật lại dữ liệu sau khi sửa thành công
//					snv.addWindowListener(new java.awt.event.WindowAdapter() {
//						public void windowClosed(java.awt.event.WindowEvent windowEvent) {
//							loadEmployeeData(); // Tải lại dữ liệu
//						}
//					});
//
//				} else {
//					JOptionPane.showMessageDialog(null, "Hãy chọn nhân vien để sửa");
//				}
//
//			}
//		});

//		btnXoa.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				int selectedRow = table.getSelectedRow();
//				if (selectedRow != -1) {
//					String maNhanVien = (String) table.getValueAt(selectedRow, 0);
//					NhanVien nhanVien1 = new NhanVien();
//					nhanVien1.setMaNhanVien(maNhanVien);
//					nhanVienDAO.delete(nhanVien1);
//					loadEmployeeData();
//					JOptionPane.showMessageDialog(null, "Xóa thành công!");
//				} else {
//					JOptionPane.showMessageDialog(null, "Hãy chọn nhân viên để xóa.");
//				}
//			}
//		});

		// btnTimKiem.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				// Lấy từ khóa tìm kiếm từ txtTimKiem
//				String keyword = txtTimKiem.getText().trim();
//				HienThiTKNV tknv = new HienThiTKNV(keyword);
//				tknv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//				tknv.setVisible(true);
//
//			}
//		});

	}

	public void loadEmployeeData() {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		for (NhanVien nv : nhanVienDAO.selectALL()) {
			model.addRow(new Object[] { nv.getMaNhanVien(), nv.getTenNhanVien(), nv.getGioiTinh(), nv.getNgaySinh(),
					nv.getDiaChi(), nv.getSoDienThoai(), nv.getMaPhongBan(), nv.getChucVu(), nv.getMucLuong() });
		}
	}

	public void timNV() {
//		String keyword = txtTimKiem.getText().trim();
//		HienThiTKNV tknv = new HienThiTKNV(keyword);
//		tknv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//		tknv.setVisible(true);

		String maNV = txtTimKiem.getText();
		if (maNV.isEmpty()) {
			
			JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã Nhân Viên cần tìm.");
			return;
		}

		NhanVien nhanVien = new NhanVien();
		nhanVien.setMaNhanVien(maNV);
		NhanVien ketQua = nhanVienDAO.selectById(nhanVien);

		if (ketQua != null) {
			tableModel.setRowCount(0); // Xóa dữ liệu hiện có trong bảng
			tableModel.addRow(new Object[] { ketQua.getMaNhanVien(), ketQua.getTenNhanVien(), ketQua.getGioiTinh(),
					ketQua.getNgaySinh(), ketQua.getDiaChi(), ketQua.getSoDienThoai(), ketQua.getMaPhongBan(),
					ketQua.getChucVu(), ketQua.getMucLuong() });
		} else {
			JOptionPane.showMessageDialog(this, "Không tìm thấy Nhân Viên có Mã: " + maNV);
		}

	}

	public void themNV() {
		ThemNV tnv = new ThemNV();
		tnv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		tnv.setVisible(true);
		// Cập nhật lại dữ liệu sau khi thêm thành công
		tnv.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosed(java.awt.event.WindowEvent windowEvent) {

				loadEmployeeData(); // Tải lại dữ liệu
			}
		});
	}

	public void suaNV() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow != -1) {
			String maNV = (String) table.getValueAt(selectedRow, 0);
			String tenNV = (String) table.getValueAt(selectedRow, 1);
			String gioiTinh = (String) table.getValueAt(selectedRow, 2);
			String ngaySinh = (String) table.getValueAt(selectedRow, 3);
			String diaChi = (String) table.getValueAt(selectedRow, 4);
			String sDTNV = (String) table.getValueAt(selectedRow, 5);
			String maPhongBanNV = (String) table.getValueAt(selectedRow, 6);
			String maChucVuNV = (String) table.getValueAt(selectedRow, 7);
			int mucLuong = Integer.parseInt(String.valueOf(table.getValueAt(selectedRow, 8)));

			NhanVien nhanvien = new NhanVien(maNV, tenNV, gioiTinh, ngaySinh, diaChi, sDTNV, maPhongBanNV, maChucVuNV,
					mucLuong);

			SuaNV snv = new SuaNV(nhanvien);
			snv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			snv.setVisible(true);
			// Cập nhật lại dữ liệu sau khi sửa thành công
			snv.addWindowListener(new java.awt.event.WindowAdapter() {
				public void windowClosed(java.awt.event.WindowEvent windowEvent) {
					loadEmployeeData(); // Tải lại dữ liệu
				}
			});

		} else {
			JOptionPane.showMessageDialog(null, "Hãy chọn nhân vien để sửa");
		}
	}

	public void xoaNV() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow != -1) {
			String maNhanVien = (String) table.getValueAt(selectedRow, 0);
			NhanVien nhanVien1 = new NhanVien();
			nhanVien1.setMaNhanVien(maNhanVien);
			nhanVienDAO.delete(nhanVien1);
			loadEmployeeData();
			JOptionPane.showMessageDialog(null, "Xóa thành công!");
		} else {
			JOptionPane.showMessageDialog(null, "Hãy chọn nhân viên để xóa.");
		}
	}

	public JTable getTable() {
		return table;
	}

	public void setTable(JTable table) {
		this.table = table;
	}

	public JButton getBtnThemNhanVien() {
		return btnThemNhanVien;
	}

	public void setBtnThemNhanVien(JButton btnThemNhanVien) {
		this.btnThemNhanVien = btnThemNhanVien;
	}

	public JButton getBtnTimKiem() {
		return btnTimKiem;
	}

	public void setBtnTimKiem(JButton btnTimKiem) {
		this.btnTimKiem = btnTimKiem;
	}

	public JButton getBtnSua() {
		return btnSua;
	}

	public void setBtnSua(JButton btnSua) {
		this.btnSua = btnSua;
	}

	public JButton getBtnXoa() {
		return btnXoa;
	}

	public void setBtnXoa(JButton btnXoa) {
		this.btnXoa = btnXoa;
	}

	public JButton getBtnRefresh() {
		return btnRefresh;
	}

	public void setBtnRefresh(JButton btnRefresh) {
		this.btnRefresh = btnRefresh;
	}

}
