package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.print.DocFlavor.STRING;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import controller.Panel_TuyenDungController;
import dao.NhanVienDAO;
import dao.TuyenDungDAO;
import model.NhanVien;
import model.TuyenDung;

public class Panel_TuyenDungView extends Panel_ManHinh {

	private static final long serialVersionUID = 1L;
	private JTextField txtTimKiem;
//    private JLabel lbMaNhanVienTT, lbTenNhanVien1, lbGioiTinh1, lbNgaySinh1, lbDiaChi1, lbSDT1, lbMaPhongBan1, lbChucVu1, lbMucLuong1;

	private TuyenDungDAO tuyenDungDAO;
	private DefaultTableModel tableModel;
	private JTable table;
	private JLabel lbMaUV1;
	private JLabel lbTenUV1;
	private JLabel lbSDTUV1;
	private JLabel lbEmailUV1;
	private JLabel lbChucVuUV1;
	private JLabel lbTrinhDoUV1;
	private JLabel lbDealLuongUV1;
	private JLabel lbTrangThaiUV1;
	private JButton btnXoa;
	private JButton btnSua;
	private JButton btnThemNhanVien;
	private JButton btnTimKiem;
	private JButton btnTuyn;
	private JButton btnRefresh;

	public Panel_TuyenDungView() {
		super();
		tuyenDungDAO = new TuyenDungDAO();
		setLayout(null);

		JPanel panel_Title = new JPanel();
		panel_Title.setBounds(0, 0, 874, 74);
		panel_Title.setBackground(new Color(255, 255, 255));
		add(panel_Title);
		panel_Title.setLayout(null);

		JLabel lblNewLabel = new JLabel("Danh sách ứng viên");
		lblNewLabel.setForeground(Color.GRAY);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16));
		lblNewLabel.setBounds(24, 20, 169, 33);
		panel_Title.add(lblNewLabel);

		txtTimKiem = new JTextField();
		txtTimKiem.setForeground(Color.GRAY);
		txtTimKiem.setText("Tìm kiếm theo mã");
		txtTimKiem.setFont(new Font("Arial", Font.PLAIN, 13));
		txtTimKiem.setBounds(235, 20, 164, 33);
		panel_Title.add(txtTimKiem);
		txtTimKiem.setColumns(10);

		
		Panel_TuyenDungController tdc = new Panel_TuyenDungController(this);
		
		btnTimKiem = new JButton("");
		btnTimKiem.setIcon(new ImageIcon(Panel_NhanVienView.class.getResource("/img_btn/pngegg.png")));
		btnTimKiem.setFont(new Font("Arial", Font.BOLD, 16));
		btnTimKiem.setBounds(203, 20, 33, 33);
		btnTimKiem.setBorderPainted(false);
		btnTimKiem.setBackground(Color.decode("#3498db"));
		btnTimKiem.setFocusPainted(false);
		btnTimKiem.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnTimKiem.addActionListener(tdc);
		panel_Title.add(btnTimKiem);

		btnThemNhanVien = new JButton("Thêm");
		btnThemNhanVien.setIcon(new ImageIcon(Panel_TuyenDungView.class.getResource("/img_btn/add3.png")));
		btnThemNhanVien.setForeground(Color.WHITE);
		btnThemNhanVien.setFont(new Font("Arial", Font.BOLD, 16));
		btnThemNhanVien.setBounds(536, 20, 104, 33);
		btnThemNhanVien.setBorderPainted(false);
		btnThemNhanVien.setBackground(Color.decode("#3498db"));
		btnThemNhanVien.setFocusPainted(false);
		btnThemNhanVien.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnThemNhanVien.addActionListener(tdc);
		panel_Title.add(btnThemNhanVien);

		btnSua = new JButton("Sửa");
		btnSua.setIcon(new ImageIcon(Panel_TuyenDungView.class.getResource("/img_btn/Edit--Streamline-Unicons.png")));
		btnSua.setForeground(Color.WHITE);
		btnSua.setFont(new Font("Arial", Font.BOLD, 16));
		btnSua.setBounds(650, 20, 93, 33);
		btnSua.setBorderPainted(false);
		btnSua.setBackground(Color.decode("#3498db"));
		btnSua.setFocusPainted(false);
		btnSua.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnSua.addActionListener(tdc);
		panel_Title.add(btnSua);

		btnXoa = new JButton("Xóa");
		btnXoa.setIcon(new ImageIcon(Panel_TuyenDungView.class.getResource("/img_btn/delete.png")));
		btnXoa.setForeground(Color.WHITE);
		btnXoa.setFont(new Font("Arial", Font.BOLD, 16));
		btnXoa.setBounds(753, 20, 93, 33);
		btnXoa.setBorderPainted(false);
		btnXoa.setBackground(new Color(253, 56, 21));
		btnXoa.setFocusPainted(false);
		btnXoa.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnXoa.addActionListener(tdc);
		panel_Title.add(btnXoa);

		btnTuyn = new JButton("Tuyển");

		btnTuyn.setForeground(Color.WHITE);
		btnTuyn.setFont(new Font("Arial", Font.BOLD, 16));
		btnTuyn.setFocusPainted(false);
		btnTuyn.setBorderPainted(false);
		btnTuyn.setBackground(new Color(52, 152, 219));
		btnTuyn.setBounds(442, 20, 84, 33);
		btnTuyn.addActionListener(tdc);
		panel_Title.add(btnTuyn);
		
		btnRefresh = new JButton("");
		btnRefresh.setIcon(new ImageIcon(Panel_TuyenDungView.class.getResource("/img_btn/icons8-refresh-16.png")));
		btnRefresh.setFont(new Font("Arial", Font.BOLD, 16));
		btnRefresh.setFocusPainted(false);
		btnRefresh.setBorderPainted(false);
		btnRefresh.setBackground(new Color(52, 152, 219));
		btnRefresh.setBounds(398, 20, 33, 33);
		btnRefresh.addActionListener(tdc);
		panel_Title.add(btnRefresh);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 84, 874, 313);
		this.add(scrollPane);

//		table = new JTable();
//		table.setModel(new DefaultTableModel(new Object[][] {},
//				new String[] { "M\u00E3 tuy\u1EC3n d\u1EE5ng", "H\u1ECD t\u00EAn", "S\u1ED1 \u0111i\u1EC7n tho\u1EA1i",
//						"Email", "Ch\u1EE9c v\u1EE5", "Tr\u00ECnh \u0111\u1ED9", "M\u1EE9c l\u01B0\u01A1ng Deal",
//						"Tr\u1EA1ng th\u00E1i" }));
//		table.getColumnModel().getColumn(6).setPreferredWidth(82);
//		table.setFont(new Font("Arial", Font.BOLD, 10));
//		scrollPane.setViewportView(table);
		
		tableModel = new DefaultTableModel(new Object[][] {},
				new String[] { "M\u00E3 tuy\u1EC3n d\u1EE5ng", "H\u1ECD t\u00EAn", "S\u1ED1 \u0111i\u1EC7n tho\u1EA1i",
						"Email", "Ch\u1EE9c v\u1EE5", "Tr\u00ECnh \u0111\u1ED9", "M\u1EE9c l\u01B0\u01A1ng Deal",
						"Tr\u1EA1ng th\u00E1i" });
		table = new JTable(tableModel);
		table.setFont(new Font("Arial", Font.BOLD, 10));
		scrollPane.setViewportView(table);

		JPanel panel_TTUngVien = new JPanel();
		panel_TTUngVien.setBackground(Color.WHITE);
		panel_TTUngVien.setBounds(0, 407, 874, 222);
		add(panel_TTUngVien);
		panel_TTUngVien.setLayout(new GridLayout(3, 6, 1, 1));

		JLabel lbMaUngVien = new JLabel("Mã ứngviên:");
		panel_TTUngVien.add(lbMaUngVien);

		lbMaUV1 = new JLabel("------------");// hiển thị mã nhân viên của nhân viên đang được click
		panel_TTUngVien.add(lbMaUV1);

		JLabel lbTenUngVien = new JLabel("Họ tên ứng viên:");
		panel_TTUngVien.add(lbTenUngVien);

		lbTenUV1 = new JLabel("------------");// hiển thị tên nhân viên của nhân viên đang được click
		panel_TTUngVien.add(lbTenUV1);

		JLabel lbSDTUV = new JLabel("Số điện thoại:");
		panel_TTUngVien.add(lbSDTUV);

		lbSDTUV1 = new JLabel("------------");// hiển thị giới tính nhân viên của nhân viên đang được click
		panel_TTUngVien.add(lbSDTUV1);

		JLabel lbEmailUV = new JLabel("Email:");
		panel_TTUngVien.add(lbEmailUV);

		lbEmailUV1 = new JLabel("------------");// hiển thị ngày sinh nhân viên của nhân viên đang được click
		panel_TTUngVien.add(lbEmailUV1);

		JLabel lbChucVuUV = new JLabel("Chức vụ:");
		panel_TTUngVien.add(lbChucVuUV);

		lbChucVuUV1 = new JLabel("------------");// hiển thị địa chỉ nhân viên của nhân viên đang được click
		panel_TTUngVien.add(lbChucVuUV1);

		JLabel lbTrinhDoUV = new JLabel("Trình độ:");
		panel_TTUngVien.add(lbTrinhDoUV);

		lbTrinhDoUV1 = new JLabel("------------");// hiển thị số điện thoại nhân viên của nhân viên đang được click
		panel_TTUngVien.add(lbTrinhDoUV1);

		JLabel lbDealLuongUV = new JLabel("Mức lương Deal:");
		panel_TTUngVien.add(lbDealLuongUV);

		lbDealLuongUV1 = new JLabel("------------");// hiển thị mã phòng ban của nhân viên của nhân viên đang được click
		panel_TTUngVien.add(lbDealLuongUV1);

		JLabel lbTrangThai = new JLabel("Trạng thái:");
		panel_TTUngVien.add(lbTrangThai);

		lbTrangThaiUV1 = new JLabel("------------");// hiển thị chức vụ nhân viên của nhân viên đang được click
		panel_TTUngVien.add(lbTrangThaiUV1);

		JLabel lbEmpty = new JLabel("");
		panel_TTUngVien.add(lbEmpty);

		JLabel lbEmpty1 = new JLabel("");// hiển thị mức lương nhân viên của nhân viên đang được click
		panel_TTUngVien.add(lbEmpty1);

		loadInternData();

		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int selectRow = table.getSelectedRow();
				if (selectRow != -1) {
					lbMaUV1.setText((String) table.getValueAt(selectRow, 0));
					lbTenUV1.setText((String) table.getValueAt(selectRow, 1));
					lbSDTUV1.setText((String) table.getValueAt(selectRow, 2));
					lbEmailUV1.setText((String) table.getValueAt(selectRow, 3));
					lbChucVuUV1.setText((String) table.getValueAt(selectRow, 4));
					lbTrinhDoUV1.setText((String) table.getValueAt(selectRow, 5));
					lbDealLuongUV1.setText(String.valueOf(table.getValueAt(selectRow, 6)));
					lbTrangThaiUV1.setText((String) table.getValueAt(selectRow, 7));

				}
			}
		});

//		btnThemNhanVien.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				ThemUngVien tuv = new ThemUngVien();
//				tuv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//				tuv.setVisible(true);
//				// Cập nhật lại dữ liệu sau khi thêm thành công
//				tuv.addWindowListener(new java.awt.event.WindowAdapter() {
//					public void windowClosed(java.awt.event.WindowEvent windowEvent) {
//						loadInternData(); // Tải lại dữ liệu
//					}
//				});
//			}
//		});

//		btnSua.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//
//				int selectedRow = table.getSelectedRow();
//				if (selectedRow != -1) {
//					String maUngVien = (String) table.getValueAt(selectedRow, 0);
//					String tenUV = (String) table.getValueAt(selectedRow, 1);
//					String sDTUV = (String) table.getValueAt(selectedRow, 2);
//					String emailUV = (String) table.getValueAt(selectedRow, 3);
//					String chucVuUV = (String) table.getValueAt(selectedRow, 4);
//					String tringDoUV = (String) table.getValueAt(selectedRow, 5);
//					int dealLuongUV = Integer.parseInt(String.valueOf(table.getValueAt(selectedRow, 6)));
//					String trangThaiUV = (String) table.getValueAt(selectedRow, 7);
//
//					TuyenDung ungVien = new TuyenDung(maUngVien, tenUV, sDTUV, emailUV, chucVuUV, tringDoUV,
//							dealLuongUV, trangThaiUV);
//					// ungVien.setMaTuyenDung(maUngVien);
//
//					SuaUngVien suv = new SuaUngVien(ungVien);
//					suv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//					suv.setVisible(true);
//					// Cập nhật lại dữ liệu sau khi sửa thành công
//					suv.addWindowListener(new java.awt.event.WindowAdapter() {
//						public void windowClosed(java.awt.event.WindowEvent windowEvent) {
//							loadInternData(); // Tải lại dữ liệu
//						}
//					});
//
//					// loadInternData();
//					// JOptionPane.showMessageDialog(null,"Xóa thành công!");
//				} else {
//					JOptionPane.showMessageDialog(null, "Hãy chọn ứng viên để sửa.");
//				}
//
//			}
//		});

//		btnXoa.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				int selectedRow = table.getSelectedRow();
//				if (selectedRow != -1) {
//					String maUngVien = (String) table.getValueAt(selectedRow, 0);
//					TuyenDung ungVien = new TuyenDung();
//					ungVien.setMaTuyenDung(maUngVien);
//					tuyenDungDAO.delete(ungVien);
//					loadInternData();
//					JOptionPane.showMessageDialog(null, "Xóa thành công!");
//				} else {
//					JOptionPane.showMessageDialog(null, "Hãy chọn ứng viên để xóa.");
//				}
//			}
//		});
//		btnTimKiem.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				// Lấy từ khóa tìm kiếm từ txtTimKiem
//				String keyword = txtTimKiem.getText().trim();
//				HienThiTKUngVien tkuv = new HienThiTKUngVien(keyword);
//				tkuv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//				tkuv.setVisible(true);
//
//			}
//		});
//		btnTuyn.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				int selectedRow = table.getSelectedRow();
//				if (selectedRow != -1) {
//					String maUngVien = (String) table.getValueAt(selectedRow, 0);
//					TuyenDung ungVien = new TuyenDung();
//					ungVien.setMaTuyenDung(maUngVien);
//					tuyenDungDAO.tuyen(ungVien);
//					loadInternData();
//					JOptionPane.showMessageDialog(null, "Tuyen thành công!");
//				} else {
//					JOptionPane.showMessageDialog(null, "Hãy chọn ứng viên để tuyen.");
//				}
//			}
//		});

	}

	public void loadInternData() {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		for (TuyenDung uv : tuyenDungDAO.selectALL()) {
			model.addRow(new Object[] { uv.getMaTuyenDung(), uv.getHoTen(), uv.getSoDienThoai(), uv.getEmail(),
					uv.getChucVu(), uv.getTrinhDo(), uv.getMucLuongDeal(), uv.getTrangThai() });
		}
	}

	public void them() {
		ThemUngVien tuv = new ThemUngVien();
		tuv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		tuv.setVisible(true);
		// Cập nhật lại dữ liệu sau khi thêm thành công
		tuv.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosed(java.awt.event.WindowEvent windowEvent) {
				loadInternData(); // Tải lại dữ liệu
			}
		});
	}

	public void sua() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow != -1) {
			String maUngVien = (String) table.getValueAt(selectedRow, 0);
			String tenUV = (String) table.getValueAt(selectedRow, 1);
			String sDTUV = (String) table.getValueAt(selectedRow, 2);
			String emailUV = (String) table.getValueAt(selectedRow, 3);
			String chucVuUV = (String) table.getValueAt(selectedRow, 4);
			String tringDoUV = (String) table.getValueAt(selectedRow, 5);
			int dealLuongUV = Integer.parseInt(String.valueOf(table.getValueAt(selectedRow, 6)));
			String trangThaiUV = (String) table.getValueAt(selectedRow, 7);

			TuyenDung ungVien = new TuyenDung(maUngVien, tenUV, sDTUV, emailUV, chucVuUV, tringDoUV,
					dealLuongUV, trangThaiUV);
			// ungVien.setMaTuyenDung(maUngVien);

			SuaUngVien suv = new SuaUngVien(ungVien);
			suv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			suv.setVisible(true);
			// Cập nhật lại dữ liệu sau khi sửa thành công
			suv.addWindowListener(new java.awt.event.WindowAdapter() {
				public void windowClosed(java.awt.event.WindowEvent windowEvent) {
					loadInternData(); // Tải lại dữ liệu
				}
			});

			// loadInternData();
			// JOptionPane.showMessageDialog(null,"Xóa thành công!");
		} else {
			JOptionPane.showMessageDialog(null, "Hãy chọn ứng viên để sửa.");
		}
	}

	public void xoa() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow != -1) {
			String maUngVien = (String) table.getValueAt(selectedRow, 0);
			TuyenDung ungVien = new TuyenDung();
			ungVien.setMaTuyenDung(maUngVien);
			tuyenDungDAO.delete(ungVien);
			loadInternData();
			JOptionPane.showMessageDialog(null, "Xóa thành công!");
		} else {
			JOptionPane.showMessageDialog(null, "Hãy chọn ứng viên để xóa.");
		}
	}

	public void tim() {
		// Lấy từ khóa tìm kiếm từ txtTimKiem
//		String keyword = txtTimKiem.getText().trim();
//		HienThiTKUngVien tkuv = new HienThiTKUngVien(keyword);
//		tkuv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//		tkuv.setVisible(true);
		
		String maTD = txtTimKiem.getText();
		if (maTD.isEmpty()) {
			
			JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã Ứng Viên cần tìm.");
			return;
		}

		
		TuyenDung tuyenDung = new TuyenDung();
		tuyenDung.setMaTuyenDung(maTD);
		TuyenDung ketQua = tuyenDungDAO.selectById(tuyenDung);

		if (ketQua != null) {
			tableModel.setRowCount(0); // Xóa dữ liệu hiện có trong bảng
			tableModel.addRow(new Object[] { ketQua.getMaTuyenDung(), ketQua.getHoTen(), ketQua.getSoDienThoai(), ketQua.getEmail(),
					ketQua.getChucVu(), ketQua.getTrinhDo(), ketQua.getMucLuongDeal(), ketQua.getTrangThai() });
		} else {
			JOptionPane.showMessageDialog(this, "Không tìm thấy Ứng Viên có Mã: " + maTD);
		}
		
	}

	public void tuyen() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow != -1) {
			String maUngVien = (String) table.getValueAt(selectedRow, 0);
			TuyenDung ungVien = new TuyenDung();
			ungVien.setMaTuyenDung(maUngVien);
			tuyenDungDAO.tuyen(ungVien);
			loadInternData();
			JOptionPane.showMessageDialog(null, "Tuyen thành công!");
		} else {
			JOptionPane.showMessageDialog(null, "Hãy chọn ứng viên để tuyen.");
		}
	}

	public JButton getBtnXoa() {
		return btnXoa;
	}

	public void setBtnXoa(JButton btnXoa) {
		this.btnXoa = btnXoa;
	}

	public JButton getBtnSua() {
		return btnSua;
	}

	public void setBtnSua(JButton btnSua) {
		this.btnSua = btnSua;
	}

	public JButton getBtnThemNhanVien() {
		return btnThemNhanVien;
	}

	public void setBtnThemNhanVien(JButton btnThemNhanVien) {
		this.btnThemNhanVien = btnThemNhanVien;
	}

	public JButton getBtnTimKiem() {
		return btnTimKiem;
	}

	public void setBtnTimKiem(JButton btnTimKiem) {
		this.btnTimKiem = btnTimKiem;
	}

	public JButton getBtnTuyn() {
		return btnTuyn;
	}

	public void setBtnTuyn(JButton btnTuyn) {
		this.btnTuyn = btnTuyn;
	}

	public JButton getBtnRefresh() {
		return btnRefresh;
	}

	public void setBtnRefresh(JButton btnRefresh) {
		this.btnRefresh = btnRefresh;
	}

}
