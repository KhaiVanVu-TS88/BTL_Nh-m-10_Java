	package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import controller.ManHinhController;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ManHinhView extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    public JLabel lbTrangChu;
	public JLabel lbNhanVien;
	public JLabel lbChamCong;
	public JLabel lbPhongBan;
	public JLabel lbLuong;
	public JLabel lbTuyenDung;
	public JLabel lbTaiKhoan;
    private JPanel panel_TrangChu, panel_TuyenDung, panel_NhanVien, panel_ChamCong, panel_PhongBan, panel_Luong, panel_TaiKhoan;

    public ManHinhView() {
    	
    	
        this.setTitle("Group 10");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1117, 686);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Sidebar setup
        JPanel sideBar = new JPanel();
        sideBar.setBackground(Color.WHITE);
        sideBar.setBounds(0, 0, 209, 649);
        contentPane.add(sideBar);
        sideBar.setLayout(null);

        
//        ManHinhController manHinhController = new ManHinhController(this);
        
        // Sidebar labels
        lbTrangChu = createSidebarLabel("Trang Chủ", "/img_sidebar/home.png", 155);
//        lbTrangChu.addMouseListener(manHinhController);
        sideBar.add(lbTrangChu);
        

        lbNhanVien = createSidebarLabel("Nhân Viên", "/img_sidebar/employee.png", 257);
        sideBar.add(lbNhanVien);

        lbChamCong = createSidebarLabel("Chấm công", "/img_sidebar/timesheets.png", 308);
        sideBar.add(lbChamCong);

        lbPhongBan = createSidebarLabel("Phòng ban", "/img_sidebar/department.png", 359);
        sideBar.add(lbPhongBan);

        lbLuong = createSidebarLabel("Lương", "/img_sidebar/salary.png", 410);
        sideBar.add(lbLuong);

        lbTuyenDung = createSidebarLabel("Tuyển Dụng", "/img_sidebar/recruitment.png", 206);
        sideBar.add(lbTuyenDung);

        lbTaiKhoan = createSidebarLabel("Tài Khoản", "/img_sidebar/account.png", 461);
        sideBar.add(lbTaiKhoan);
        
        new ManHinhController(this);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_big/icons8-male-user-100.png")));
        lblNewLabel.setBounds(42, 10, 100, 114);
        sideBar.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("Admin");
        lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 16));
        lblNewLabel_1.setForeground(new Color(1, 143, 190));
        lblNewLabel_1.setBounds(67, 122, 72, 24);
        sideBar.add(lblNewLabel_1);

        // Panels setup
        panel_TrangChu = new Panel_TrangChuView();
        //panel_TrangChu = createPanel(Color.WHITE);
        contentPane.add(panel_TrangChu);

        panel_TuyenDung = new Panel_TuyenDungView();
        contentPane.add(panel_TuyenDung);

//        panel_NhanVien = createPanel(new Color(0, 206, 209));
//        contentPane.add(panel_NhanVien);
        panel_NhanVien =  new Panel_NhanVienView();
        contentPane.add(panel_NhanVien);

//        panel_ChamCong = createPanel(new Color(0, 250, 154));
        panel_ChamCong = new Panel_ChamCongView();
        contentPane.add(panel_ChamCong);
        
        
        panel_PhongBan = new Panel_PhongBanView();
//        panel_PhongBan = createPanel(new Color(0, 255, 0));
        contentPane.add(panel_PhongBan);

        //panel_Luong = createPanel(Color.RED);
        panel_Luong = new Panel_LuongView();
        contentPane.add(panel_Luong);
        
        
        panel_TaiKhoan = new Panel_TaiKhoanView();
//        panel_TaiKhoan = createPanel(new Color(255, 127, 80));
        contentPane.add(panel_TaiKhoan);
        
//        JLabel lbNenManHinh = new JLabel("NenManHinh");
//        lbNenManHinh.setFont(new Font("Arial", Font.BOLD, 59));
//        lbNenManHinh.setBounds(400, 275, 409, 218);
//        contentPane.add(lbNenManHinh);

        // Default panel visibility
        showPanel("Trang chủ");

        this.setVisible(true);
    }

    private JLabel createSidebarLabel(String text, String iconPath, int yPosition) {
        JLabel label = new JLabel(text, SwingConstants.LEFT);
        label.setIcon(new ImageIcon(ManHinhView.class.getResource(iconPath)));
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setBounds(10, yPosition, 189, 41);
        label.setOpaque(true);
        label.setBackground(Color.WHITE);
        label.setForeground(Color.BLACK);
//        label.addMouseListener(new MouseAdapter() {
//            @Override
//            public void mouseClicked(MouseEvent e) {
//                showPanel(text);
//            }
//        });
        return label;
    }

    private JPanel createPanel(Color color) {
        JPanel panel = new JPanel();
        panel.setBackground(color);
        panel.setBounds(219, 10, 874, 629);
        panel.setLayout(null);
        return panel;
    }

    public void showPanel(String panelName) {
        panel_TrangChu.setVisible(false);
        panel_TuyenDung.setVisible(false);
        panel_NhanVien.setVisible(false);
        panel_ChamCong.setVisible(false);
        panel_PhongBan.setVisible(false);
        panel_Luong.setVisible(false);
        panel_TaiKhoan.setVisible(false);

        resetSidebarStyles();

        switch (panelName) {
            case "Trang Chủ":
                panel_TrangChu.setVisible(true);
                setActiveSidebarLabel(lbTrangChu);
                lbTrangChu.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/home2.png")));
                lbTuyenDung.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/recruitment.png")));
                lbNhanVien.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/employee.png")));
                lbChamCong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/timesheets.png")));
                lbPhongBan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/department.png")));
                lbLuong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/salary.png")));
                lbTaiKhoan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/account.png")));
                break;
            case "Tuyển Dụng":
                panel_TuyenDung.setVisible(true);
                setActiveSidebarLabel(lbTuyenDung);
                lbTrangChu.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/home.png")));
                lbTuyenDung.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/recruitment2.png")));
                lbNhanVien.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/employee.png")));
                lbChamCong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/timesheets.png")));
                lbPhongBan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/department.png")));
                lbLuong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/salary.png")));
                lbTaiKhoan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/account.png")));
                break;
            case "Nhân Viên":
                panel_NhanVien.setVisible(true);
                setActiveSidebarLabel(lbNhanVien);
                lbTrangChu.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/home.png")));
                lbTuyenDung.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/recruitment.png")));
                lbNhanVien.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/employee2.png")));
                lbChamCong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/timesheets.png")));
                lbPhongBan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/department.png")));
                lbLuong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/salary.png")));
                lbTaiKhoan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/account.png")));
                break;
            case "Chấm công":
                panel_ChamCong.setVisible(true);
                setActiveSidebarLabel(lbChamCong);
                lbTrangChu.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/home.png")));
                lbTuyenDung.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/recruitment.png")));
                lbNhanVien.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/employee.png")));
                lbChamCong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/timesheets2.png")));
                lbPhongBan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/department.png")));
                lbLuong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/salary.png")));
                lbTaiKhoan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/account.png")));
                break;
            case "Phòng ban":
                panel_PhongBan.setVisible(true);
                setActiveSidebarLabel(lbPhongBan);
                lbTrangChu.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/home.png")));
                lbTuyenDung.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/recruitment.png")));
                lbNhanVien.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/employee.png")));
                lbChamCong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/timesheets.png")));
                lbPhongBan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/department2.png")));
                lbLuong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/salary.png")));
                lbTaiKhoan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/account.png")));
                break;
            case "Lương":
                panel_Luong.setVisible(true);
                setActiveSidebarLabel(lbLuong);
                lbTrangChu.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/home.png")));
                lbTuyenDung.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/recruitment.png")));
                lbNhanVien.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/employee.png")));
                lbChamCong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/timesheets.png")));
                lbPhongBan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/department.png")));
                lbLuong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/salary2.png")));
                lbTaiKhoan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/account.png")));
                break;
            case "Tài Khoản":
                panel_TaiKhoan.setVisible(true);
                setActiveSidebarLabel(lbTaiKhoan);
                lbTrangChu.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/home.png")));
                lbTuyenDung.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/recruitment.png")));
                lbNhanVien.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/employee.png")));
                lbChamCong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/timesheets.png")));
                lbPhongBan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/department.png")));
                lbLuong.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/salary.png")));
                lbTaiKhoan.setIcon(new ImageIcon(ManHinhView.class.getResource("/img_sidebar/account2.png")));
                break;
        }
    }

    private void setActiveSidebarLabel(JLabel label) {
        label.setBackground(SystemColor.textHighlight);
        label.setForeground(Color.WHITE);
    }

    private void resetSidebarStyles() {
        JLabel[] labels = {lbTrangChu, lbTuyenDung, lbNhanVien, lbChamCong, lbPhongBan, lbLuong, lbTaiKhoan};
        for (JLabel label : labels) {
            label.setBackground(Color.WHITE);
            label.setForeground(Color.BLACK);
        }
    }
    
//    public static void main(String[] args) {
//		ManHinhView view = new ManHinhView();
//	}
}
