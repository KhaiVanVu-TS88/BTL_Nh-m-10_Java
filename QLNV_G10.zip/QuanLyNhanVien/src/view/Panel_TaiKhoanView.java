//PanelTaiKhoan
package view;

import dao.TaiKhoanDAO;
import model.TaiKhoan;

import javax.swing.*;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;

import controller.Panel_TaiKhoanController;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Panel_TaiKhoanView extends Panel_ManHinh {

    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtMaNhanVien, txtQuyen;
    private JButton btnThem, btnSua, btnXoa;
    private TaiKhoanDAO taiKhoanDAO;
    private JButton btnRefresh;

    public Panel_TaiKhoanView() {
        super();
        taiKhoanDAO = TaiKhoanDAO.getInstance();
        setLayout(new BorderLayout());

        // Initialize Table
        tableModel = new DefaultTableModel(new Object[]{"Mã Nhân Viên", "Quyền"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Panel for input fields
        JPanel inputPanel = createInputPanel();

        // Panel for buttons
        JPanel buttonPanel = createButtonPanel();

        // Add components to main panel
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Load existing data from DAO
        loadTaiKhoanData();

        //Controller
        Panel_TaiKhoanController tkc = new Panel_TaiKhoanController(this);
        
        btnThem.addActionListener(tkc);
        btnSua.addActionListener(tkc);
        btnXoa.addActionListener(tkc);
        btnRefresh.addActionListener(tkc);
        
        // Set button actions using lambda expressions
//        btnThem.addActionListener(e -> themTaiKhoan());
//        btnSua.addActionListener(e -> suaTaiKhoan());
//        btnXoa.addActionListener(e -> xoaTaiKhoan());
//        btnRefresh.addActionListener(e -> loadTaiKhoanData());
    }

    // Creates input panel with fields
    private JPanel createInputPanel() {
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(7, 2, 10, 10)); // 2 rows, 2 columns, with gap of 10px

        inputPanel.add(new JLabel("Mã Nhân Viên:"));
        txtMaNhanVien = new JTextField();
        inputPanel.add(txtMaNhanVien);

        inputPanel.add(new JLabel("Quyền:"));
        txtQuyen = new JTextField();
        inputPanel.add(txtQuyen);

        return inputPanel;
    }

    // Creates the button panel
    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        btnThem = new JButton("Thêm");
        btnThem.setBorderPainted(false);
        btnThem.setBackground(Color.decode("#3498db"));
        btnThem.setFocusPainted(false);
        btnThem.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnThem.setForeground(Color.white);

        btnSua = new JButton("Sửa");
        btnSua.setBorderPainted(false);
        btnSua.setBackground(Color.decode("#3498db"));
        btnSua.setFocusPainted(false);
        btnSua.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSua.setForeground(Color.white);

        btnXoa = new JButton("Xóa");
        btnXoa.setBorderPainted(false);
        btnXoa.setBackground(Color.decode("#e74c3c"));
        btnXoa.setFocusPainted(false);
        btnXoa.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnXoa.setForeground(Color.white);

        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        
        btnRefresh = new JButton("Refresh");
//        btnRefresh.addActionListener(new ActionListener() {
//        	public void actionPerformed(ActionEvent e) {
//        		loadTaiKhoanData();
//        	}
//        });
        btnRefresh.setForeground(new Color(255, 255, 255));
        btnRefresh.setBorderPainted(false);
        btnRefresh.setBackground(Color.decode("#3498db"));
        btnRefresh.setFocusPainted(false);
        btnRefresh.setCursor(new Cursor(Cursor.HAND_CURSOR));
        buttonPanel.add(btnRefresh);
        return buttonPanel;
    }

    // Add new account
    public void themTaiKhoan() {
        if (validateInput()) {
            String maNV = txtMaNhanVien.getText();
            String quyen = txtQuyen.getText();

            // Create TaiKhoan object
            TaiKhoan taiKhoan = new TaiKhoan(maNV, quyen);

            // Add to database
            int result = taiKhoanDAO.insert(taiKhoan);

            if (result > 0) {
                // Add to tableModel to display
                Object[] row = {maNV, quyen};
                tableModel.addRow(row);
                JOptionPane.showMessageDialog(this, "Thêm thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Thêm thất bại!");
            }
        }
    }

    // Edit account
    public void suaTaiKhoan() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String maNV = txtMaNhanVien.getText();
            String quyen = txtQuyen.getText();

            // Create TaiKhoan object
            TaiKhoan taiKhoan = new TaiKhoan(maNV, quyen);

            // Update in database
            int result = taiKhoanDAO.update(taiKhoan);

            if (result > 0) {
                // Update in tableModel
                tableModel.setValueAt(maNV, selectedRow, 0);
                tableModel.setValueAt(quyen, selectedRow, 1);
                JOptionPane.showMessageDialog(this, "Sửa thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Sửa thất bại!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn tài khoản cần sửa.");
        }
    }

    // Delete account
    public void xoaTaiKhoan() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa không?", "Xác nhận", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                // Lấy mã nhân viên của hàng được chọn
                String maNV = tableModel.getValueAt(selectedRow, 0).toString();

                // Tạo đối tượng tài khoản để xóa
                TaiKhoan taiKhoan = new TaiKhoan();
                taiKhoan.setMaNhanVien(maNV);

                // Xóa khỏi cơ sở dữ liệu
                int result = TaiKhoanDAO.getInstance().delete(taiKhoan);

                if (result > 0) {
                    // Xóa khỏi tableModel
                    tableModel.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(this, "Xóa thành công!");
                } else {
                    JOptionPane.showMessageDialog(this, "Xóa thất bại! Không tìm thấy tài khoản.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn tài khoản cần xóa.");
        }
    }

    // Validate input fields for empty data
    public boolean validateInput() {
        if (txtMaNhanVien.getText().isEmpty() || txtQuyen.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mã nhân viên và Quyền không được để trống.");
            return false;
        }
        return true;
    }

    // Load account data from DAO
    public void loadTaiKhoanData() {
    	DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
        
        for (TaiKhoan tk : taiKhoanDAO.selectALL()) {
        	model.addRow(new Object[]{
                tk.getMaNhanVien(), tk.getQuyen()
            });
        }
    }

	public JButton getBtnThem() {
		return btnThem;
	}

	public void setBtnThem(JButton btnThem) {
		this.btnThem = btnThem;
	}

	public JButton getBtnSua() {
		return btnSua;
	}

	public void setBtnSua(JButton btnSua) {
		this.btnSua = btnSua;
	}

	public JButton getBtnXoa() {
		return btnXoa;
	}

	public void setBtnXoa(JButton btnXoa) {
		this.btnXoa = btnXoa;
	}

	public JButton getBtnRefresh() {
		return btnRefresh;
	}

	public void setBtnRefresh(JButton btnRefresh) {
		this.btnRefresh = btnRefresh;
	}
    
    
}
