package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DangNhapView extends JFrame {

	private static final long serialVersionUID = 1L;
	private static JPanel contentPane;
	private static JTextField userName;
	private static JPasswordField passWord;
	private static JButton btnLogin;

	public DangNhapView() {
		showWindow();
	}

	public static void showWindow() {
		JFrame frame = new JFrame("LOGIN");
		//this.setTitle("LOGIN");
		//this.setLocationRelativeTo(null);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 868, 526);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		frame.setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(30, 144, 255));
		panel.setBounds(0, 0, 445, 489);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("WELCOME");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 40));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(63, 109, 218, 97);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("TO GROUP10'S PROJECT");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 25));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(63, 184, 372, 51);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(DangNhapView.class.getResource("/img_big/icons8-employee-96.png")));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 49));
		lblNewLabel_2.setBounds(269, 78, 107, 120);
		panel.add(lblNewLabel_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(441, 0, 414, 489);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("LOGIN");
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(177, 26, 66, 59);
		panel_1.add(lblNewLabel_3);
		
		JLabel lbUserName = new JLabel("UserName");
		lbUserName.setForeground(Color.LIGHT_GRAY);
		lbUserName.setFont(new Font("Arial", Font.BOLD, 16));
		lbUserName.setBounds(54, 135, 93, 33);
		panel_1.add(lbUserName);
		
		userName = new JTextField();
		userName.setForeground(Color.GRAY);
		userName.setFont(new Font("Arial", Font.PLAIN, 14));
		userName.setBounds(54, 167, 294, 33);
		userName.setBorder(null);
		panel_1.add(userName);
		userName.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.LIGHT_GRAY);
		separator.setBackground(Color.LIGHT_GRAY);
		separator.setBounds(54, 207, 294, 19);
		panel_1.add(separator);
		
		JLabel lbPassWord = new JLabel("PassWord");
		lbPassWord.setForeground(Color.LIGHT_GRAY);
		lbPassWord.setFont(new Font("Arial", Font.BOLD, 16));
		lbPassWord.setBounds(54, 217, 93, 33);
		panel_1.add(lbPassWord);
		
		passWord = new JPasswordField();
		passWord.setForeground(Color.GRAY);
		passWord.setBounds(54, 245, 294, 33);
		passWord.setBorder(null);
		panel_1.add(passWord);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setForeground(Color.LIGHT_GRAY);
		separator_2.setBackground(Color.LIGHT_GRAY);
		separator_2.setBounds(54, 286, 294, 19);
		panel_1.add(separator_2);
		
		btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = userName.getText();
		        String pass = new String(passWord.getPassword());
 
		        if (name.equals("admin") && pass.equals("123456")) {
		            frame.setVisible(false);
		            ManHinhView manHinh = new ManHinhView();
		            manHinh.setVisible(true); // Hiển thị cửa sổ ManHinh
		            System.out.println("Đăng nhập thành công tài khoản "+name);
		        } else {
		            JOptionPane.showMessageDialog(null, "Đăng nhập không thành công!");
		            System.out.println("Đăng nhập không thành công!");
		        }
				
				
			}
		});
		btnLogin.setFont(new Font("Arial", Font.BOLD, 18));
		btnLogin.setForeground(new Color(255, 255, 255));
		btnLogin.setBounds(86, 334, 240, 42);
		
		btnLogin.setBorderPainted(false);
		btnLogin.setBackground(new Color(0, 191, 255));
		btnLogin.setFocusPainted(false);
		btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		panel_1.add(btnLogin);
		
		
		frame.setVisible(true);
	}
	
}
