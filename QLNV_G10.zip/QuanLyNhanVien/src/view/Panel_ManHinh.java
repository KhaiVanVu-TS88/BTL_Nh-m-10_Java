package view;

import javax.swing.JPanel;

public class Panel_ManHinh extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public Panel_ManHinh() {
		this.setBounds(219, 10, 874, 629);
		this.setLayout(null);
	}

}
