package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.NhanVienDAO;
import model.NhanVien;

public class SuaNV extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTextField tfMaNhanVien, tfTenNhanVien, tfGioiTinh, tfNgaySinh, tfDiaChi, tfSoDienThoai, tfMaPhongBan, tfChucVu, tfMucLuong;

    public SuaNV(NhanVien nhanVien) {
        this.setTitle("Sửa nhân viên");
        this.setLocation(100, 100);
        this.setSize(763, 321);
        getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 1, 746, 226);
        panel.setBackground(new Color(255, 255, 255));
        getContentPane().add(panel);
        panel.setLayout(new GridLayout(3, 6, 10, 50));

        // Mã nhân viên
        JLabel lbMaNhanVien = new JLabel("Mã nhân viên:");
        lbMaNhanVien.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMaNhanVien);
        tfMaNhanVien = new JTextField(nhanVien.getMaNhanVien());
        panel.add(tfMaNhanVien);

        // Tên nhân viên
        JLabel lbTenNhanVien = new JLabel("Tên nhân viên:");
        lbTenNhanVien.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbTenNhanVien);
        tfTenNhanVien = new JTextField(nhanVien.getTenNhanVien());
        panel.add(tfTenNhanVien);

        // Giới tính
        JLabel lbGioiTinh = new JLabel("Giới tính:");
        lbGioiTinh.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbGioiTinh);
        tfGioiTinh = new JTextField(nhanVien.getGioiTinh());
        panel.add(tfGioiTinh);

        // Ngày sinh
        JLabel lbNgaySinh = new JLabel("Ngày sinh:");
        lbNgaySinh.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbNgaySinh);
        tfNgaySinh = new JTextField(nhanVien.getNgaySinh());
        panel.add(tfNgaySinh);

        // Địa chỉ
        JLabel lbDiaChi = new JLabel("Địa chỉ:");
        lbDiaChi.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbDiaChi);
        tfDiaChi = new JTextField(nhanVien.getDiaChi());
        panel.add(tfDiaChi);

        // Số điện thoại
        JLabel lbSDT = new JLabel("Số điện thoại:");
        lbSDT.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbSDT);
        tfSoDienThoai = new JTextField(nhanVien.getSoDienThoai());
        panel.add(tfSoDienThoai);

        // Mã phòng ban
        JLabel lbMaPhongBan = new JLabel("Mã phòng ban:");
        lbMaPhongBan.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMaPhongBan);
        tfMaPhongBan = new JTextField(nhanVien.getMaPhongBan());
        panel.add(tfMaPhongBan);

        // Chức vụ
        JLabel lbChucVu = new JLabel("Chức vụ:");
        lbChucVu.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbChucVu);
        tfChucVu = new JTextField(nhanVien.getChucVu());
        panel.add(tfChucVu);

        // Mức lương
        JLabel lbMucLuong = new JLabel("Mức lương:");
        lbMucLuong.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMucLuong);
        tfMucLuong = new JTextField(String.valueOf(nhanVien.getMucLuong()));
        panel.add(tfMucLuong);

        // Nút Sửa
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(255, 255, 255));
        panel_1.setBounds(0, 225, 746, 59);
        getContentPane().add(panel_1);
        panel_1.setLayout(null);

        JButton btnSua = new JButton("Sửa");
        btnSua.setForeground(new Color(255, 255, 255));
        btnSua.setBounds(538, 10, 89, 39);
        btnSua.setFont(new Font("Arial", Font.BOLD, 18));
        btnSua.setBorderPainted(false);
        btnSua.setBackground(Color.decode("#3498db"));
        btnSua.setFocusPainted(false);
        btnSua.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panel_1.add(btnSua);

        // Xử lý sự kiện khi click vào nút "Sửa"
        btnSua.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lấy dữ liệu từ các trường nhập liệu
                String maNhanVien = tfMaNhanVien.getText();
                String tenNhanVien = tfTenNhanVien.getText();
                String gioiTinh = tfGioiTinh.getText();
                String ngaySinh = tfNgaySinh.getText();
                String diaChi = tfDiaChi.getText();
                String soDienThoai = tfSoDienThoai.getText();
                String maPhongBan = tfMaPhongBan.getText();
                String chucVu = tfChucVu.getText();
                int mucLuong = Integer.parseInt(tfMucLuong.getText());

                // Tạo đối tượng NhanVien và gọi phương thức update
                NhanVien nhanVien = new NhanVien(maNhanVien, tenNhanVien, gioiTinh, ngaySinh, diaChi, soDienThoai, maPhongBan, chucVu, mucLuong);
                NhanVienDAO nhanVienDAO = NhanVienDAO.getInstance();

                // Cập nhật thông tin nhân viên vào cơ sở dữ liệu
                int result = nhanVienDAO.update(nhanVien);

                if (result > 0) {
                    JOptionPane.showMessageDialog(null, "Cập nhật thông tin nhân viên thành công!");
                } else {
                    JOptionPane.showMessageDialog(null, "Cập nhật thông tin nhân viên thất bại!");
                }
            }
        });
    }

}
