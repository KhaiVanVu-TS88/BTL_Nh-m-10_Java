package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import controller.Panel_LuongController;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import dao.LuongDAO;
import dao.NhanVienDAO;
import model.Luong;

public class Panel_LuongView extends Panel_ManHinh {
    private JTable tableLuong;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    private JComboBox<String> comboBoxSort;
    private JButton btnSort, btnSearch, btnReset, btnReverse, btnEditLuong;
    private JTextField txtSearchMaNhanVien, txtSearchThoiGian, txtSearchThucLanh;

    public Panel_LuongView() {
        setLayout(new BorderLayout(10, 10));

        // Title Panel
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel lblTitle = new JLabel("BẢNG LƯƠNG NHÂN VIÊN");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitle.setForeground(new Color(33, 97, 140));
        titlePanel.add(lblTitle);
        add(titlePanel, BorderLayout.NORTH);

        //Controller
        Panel_LuongController lc = new Panel_LuongController(this);
        
        // Control Panel
        JPanel controlPanel = new JPanel(new BorderLayout(10, 10));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Sort Panel
        JPanel sortPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        comboBoxSort = new JComboBox<>(new String[]{"Theo Mã Nhân Viên", "Theo Thời Gian", "Theo Phụ Cấp", "Theo Thưởng", "Theo Phạt", "Theo Thuế", "Theo Thực Lãnh"});
        btnSort = new JButton("Sắp Xếp");
//        btnSort.addActionListener(e -> sortLuongData());//
        btnSort.addActionListener(lc);
        btnReverse = new JButton("Đảo Ngược");
//        btnReverse.addActionListener(e -> reverseTableData());//
        btnReverse.addActionListener(lc);
        
        btnSort.setBorderPainted(false);
        btnSort.setBackground(Color.decode("#3498db"));
        btnSort.setFocusPainted(false);
        btnSort.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSort.setForeground(Color.white);

        btnReverse.setBorderPainted(false);
        btnReverse.setBackground(Color.decode("#3498db"));
        btnReverse.setFocusPainted(false);
        btnReverse.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnReverse.setForeground(Color.white);
        
        sortPanel.add(new JLabel("Sắp Xếp:"));
        sortPanel.add(comboBoxSort);
        sortPanel.add(btnSort);
        sortPanel.add(btnReverse);
        controlPanel.add(sortPanel, BorderLayout.NORTH);

        // Search Panel
        JPanel searchPanel = new JPanel(new GridLayout(2, 4, 10, 10));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Tìm Kiếm"));

        txtSearchMaNhanVien = new JTextField();
        txtSearchThoiGian = new JTextField();
        txtSearchThucLanh = new JTextField();

        searchPanel.add(new JLabel("Mã Nhân Viên:"));
        searchPanel.add(txtSearchMaNhanVien);
        searchPanel.add(new JLabel("Thời Gian:"));
        searchPanel.add(txtSearchThoiGian);
        searchPanel.add(new JLabel("Thực Lãnh:"));
        searchPanel.add(txtSearchThucLanh);

        btnSearch = new JButton("Tìm Kiếm");
//        btnSearch.addActionListener(e -> searchLuongData());//
        btnSearch.addActionListener(lc);
        btnReset = new JButton("Đặt Lại");
//        btnReset.addActionListener(e -> resetSearch());//
        btnReset.addActionListener(lc);
        btnEditLuong = new JButton("Sửa Lương");
//        btnEditLuong.addActionListener(e -> editLuong());//
        btnEditLuong.addActionListener(lc);
        
        btnSearch.setBorderPainted(false);
        btnSearch.setBackground(Color.decode("#3498db"));
        btnSearch.setFocusPainted(false);
        btnSearch.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSearch.setForeground(Color.white);
        
        btnReset.setBorderPainted(false);
        btnReset.setBackground(Color.decode("#3498db"));
        btnReset.setFocusPainted(false);
        btnReset.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnReset.setForeground(Color.white);
        
        btnEditLuong.setBorderPainted(false);
        btnEditLuong.setBackground(Color.decode("#3498db"));
        btnEditLuong.setFocusPainted(false);
        btnEditLuong.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnEditLuong.setForeground(Color.white);
        

        searchPanel.add(btnSearch);
        searchPanel.add(btnReset);
        controlPanel.add(searchPanel, BorderLayout.CENTER);

        controlPanel.add(btnEditLuong, BorderLayout.SOUTH);

        add(controlPanel, BorderLayout.SOUTH);

        // Table Panel
        String[] columnNames = {"Mã Lương", "Mã Nhân Viên", "Thời Gian", "Phụ Cấp", "Thưởng", "Phạt", "Thuế", "Thực Lãnh"};
        tableModel = new DefaultTableModel(columnNames, 0);
        tableLuong = new JTable(tableModel);
        tableLuong.setRowHeight(25);
        JTableHeader header = tableLuong.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 13));
        scrollPane = new JScrollPane(tableLuong);
        add(scrollPane, BorderLayout.CENTER);

        loadLuongData();
    }

    public void loadLuongData() {
        ArrayList<Luong> luongList = LuongDAO.getInstance().selectALL();
        tableModel.setRowCount(0);
        for (Luong luong : luongList) {
            tableModel.addRow(new Object[]{
                    luong.getMaLuong(),
                    luong.getMaNhanVien(),
                    luong.getThoiGian(),
                    luong.getPhuCap(),
                    luong.getThuong(),
                    luong.getPhat(),
                    luong.getThue(),
                    luong.getThucLanh()
            });
        }
    }

    public void resetSearch() {
        txtSearchMaNhanVien.setText("");
        txtSearchThoiGian.setText("");
        txtSearchThucLanh.setText("");
        loadLuongData();
    }

    public void searchLuongData() {
        ArrayList<Luong> luongList = LuongDAO.getInstance().selectALL();
        String maNhanVien = txtSearchMaNhanVien.getText().trim();
        String thoiGian = txtSearchThoiGian.getText().trim();
        String thucLanhStr = txtSearchThucLanh.getText().trim();

        tableModel.setRowCount(0);

        for (Luong luong : luongList) {
            boolean matches = true;
            if (!maNhanVien.isEmpty() && !luong.getMaNhanVien().contains(maNhanVien)) matches = false;
            if (!thoiGian.isEmpty() && !luong.getThoiGian().contains(thoiGian)) matches = false;
            if (!thucLanhStr.isEmpty() && luong.getThucLanh() != Integer.parseInt(thucLanhStr)) matches = false;

            if (matches) {
                tableModel.addRow(new Object[]{
                        luong.getMaLuong(),
                        luong.getMaNhanVien(),
                        luong.getThoiGian(),
                        luong.getPhuCap(),
                        luong.getThuong(),
                        luong.getPhat(),
                        luong.getThue(),
                        luong.getThucLanh()
                });
            }
        }
    }

    public void sortLuongData() {
        String criteria = (String) comboBoxSort.getSelectedItem();
        ArrayList<Luong> luongList = LuongDAO.getInstance().selectALL();

        switch (criteria) {
            case "Theo Mã Nhân Viên" -> luongList.sort(Comparator.comparing(Luong::getMaNhanVien));
            case "Theo Thời Gian" -> luongList.sort(Comparator.comparing(Luong::getThoiGian));
            case "Theo Phụ Cấp" -> luongList.sort(Comparator.comparingInt(Luong::getPhuCap));
            case "Theo Thưởng" -> luongList.sort(Comparator.comparingInt(Luong::getThuong));
            case "Theo Phạt" -> luongList.sort(Comparator.comparingInt(Luong::getPhat));
            case "Theo Thuế" -> luongList.sort(Comparator.comparingInt(Luong::getThue));
            case "Theo Thực Lãnh" -> luongList.sort(Comparator.comparingInt(Luong::getThucLanh));
        }
        reloadTable(luongList);
    }

    public void reverseTableData() {
        ArrayList<Luong> luongList = LuongDAO.getInstance().selectALL();
        Collections.reverse(luongList);
        reloadTable(luongList);
    }

    public void reloadTable(ArrayList<Luong> luongList) {
        tableModel.setRowCount(0);
        for (Luong luong : luongList) {
            tableModel.addRow(new Object[]{
                    luong.getMaLuong(),
                    luong.getMaNhanVien(),
                    luong.getThoiGian(),
                    luong.getPhuCap(),
                    luong.getThuong(),
                    luong.getPhat(),
                    luong.getThue(),
                    luong.getThucLanh()
            });
        }
    }

    public void editLuong() {
        int selectedRow = tableLuong.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một dòng để sửa!", "Thông Báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Lấy các giá trị hiện tại từ bảng
        String maLuong = tableModel.getValueAt(selectedRow, 0).toString();
        String maNhanVien = tableModel.getValueAt(selectedRow, 1).toString(); // Giữ nguyên mã nhân viên
        String thoiGian = tableModel.getValueAt(selectedRow, 2).toString(); // Giữ nguyên thời gian
        String phuCapCu = tableModel.getValueAt(selectedRow, 3).toString();
        String thuongCu = tableModel.getValueAt(selectedRow, 4).toString();
        String phatCu = tableModel.getValueAt(selectedRow, 5).toString();
        String thueCu = tableModel.getValueAt(selectedRow, 6).toString();
        String thucLanhCu = tableModel.getValueAt(selectedRow, 7).toString();

        try {
            // Nhập các giá trị mới
            String phuCapMoi = JOptionPane.showInputDialog(this, "Nhập phụ cấp mới:", phuCapCu);
            String thuongMoi = JOptionPane.showInputDialog(this, "Nhập thưởng mới:", thuongCu);
            String phatMoi = JOptionPane.showInputDialog(this, "Nhập phạt mới:", phatCu);
            String thueMoi = JOptionPane.showInputDialog(this, "Nhập thuế mới:", thueCu);
            //String thucLanhMoi = JOptionPane.showInputDialog(this, "Thực lãnh cũ", thucLanhCu);

            // Chuyển đổi các giá trị nhập thành số nguyên
            int phuCap = Integer.parseInt(phuCapMoi);
            int thuong = Integer.parseInt(thuongMoi);
            int phat = Integer.parseInt(phatMoi);
            int thue = Integer.parseInt(thueMoi);
            int luongcb = NhanVienDAO.getInstance().getLuongCB(maNhanVien);
            int thucLanh = luongcb + phuCap + thuong - phat-thue;

            // Tạo đối tượng Luong và cập nhật các giá trị mới
            Luong luong = new Luong();
            luong.setMaLuong(maLuong); // Giữ nguyên mã lương
            luong.setMaNhanVien(maNhanVien); // Giữ nguyên mã nhân viên
            luong.setThoiGian(thoiGian); // Giữ nguyên thời gian
            luong.setPhuCap(phuCap);
            luong.setThuong(thuong);
            luong.setPhat(phat);
            luong.setThue(thue);
            luong.setThucLanh(thucLanh);

            // Thực hiện cập nhật vào cơ sở dữ liệu
            int success = LuongDAO.getInstance().update(luong);
            if (success > 0) {
                // Cập nhật trực tiếp trên bảng
                tableModel.setValueAt(phuCap, selectedRow, 3);
                tableModel.setValueAt(thuong, selectedRow, 4);
                tableModel.setValueAt(phat, selectedRow, 5);
                tableModel.setValueAt(thue, selectedRow, 6);
                tableModel.setValueAt(thucLanh, selectedRow, 7);

                JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Cập nhật thất bại!");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập các giá trị số nguyên hợp lệ cho phụ cấp, thưởng, phạt, thuế và thực lãnh!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

	public JButton getBtnSort() {
		return btnSort;
	}

	public void setBtnSort(JButton btnSort) {
		this.btnSort = btnSort;
	}

	public JButton getBtnSearch() {
		return btnSearch;
	}

	public void setBtnSearch(JButton btnSearch) {
		this.btnSearch = btnSearch;
	}

	public JButton getBtnReset() {
		return btnReset;
	}

	public void setBtnReset(JButton btnReset) {
		this.btnReset = btnReset;
	}

	public JButton getBtnReverse() {
		return btnReverse;
	}

	public void setBtnReverse(JButton btnReverse) {
		this.btnReverse = btnReverse;
	}

	public JButton getBtnEditLuong() {
		return btnEditLuong;
	}

	public void setBtnEditLuong(JButton btnEditLuong) {
		this.btnEditLuong = btnEditLuong;
	}


}
