package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.NhanVienDAO;
import dao.TuyenDungDAO;
import model.NhanVien;
import model.TuyenDung;

public class ThemUngVien extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTextField tfMaUngVien, tfTenUngVien, tfSoDienThoai, tfEmail, tfChucVu, tfTrinhDo, tfDealLuong, tfTrangThai;
	private JComboBox cmbTrangThai;

    public ThemUngVien() {
        this.setTitle("Thêm ứng viên");
        this.setLocation(100, 100);
        this.setSize(763, 334);
        getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 1, 746, 226);
        panel.setBackground(new Color(255, 255, 255));
        getContentPane().add(panel);
        panel.setLayout(new GridLayout(3, 6, 10, 50));

        // Mã ứng viên
        JLabel lbMaUngVien = new JLabel("Mã ứng viên:");
        lbMaUngVien.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMaUngVien);
        tfMaUngVien = new JTextField();
        panel.add(tfMaUngVien);

        // Tên ứng viên
        JLabel lbHoTenUngVien = new JLabel("Họ tên ứng viên:");
        lbHoTenUngVien.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbHoTenUngVien);
        tfTenUngVien = new JTextField();
        panel.add(tfTenUngVien);

        // số điện thoại
        JLabel lbSoDienThoai = new JLabel("Số điện thoại:");
        lbSoDienThoai.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbSoDienThoai);
        tfSoDienThoai = new JTextField();
        panel.add(tfSoDienThoai);

        // email
        JLabel lbEmail = new JLabel("Email:");
        lbEmail.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbEmail);
        tfEmail = new JTextField();
        panel.add(tfEmail);

        // chức vụ
        JLabel lbChucVu = new JLabel("Chức vụ:");
        lbChucVu.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbChucVu);
        tfChucVu = new JTextField();
        panel.add(tfChucVu);

        // truinhf độ
        JLabel lbTrinhDo = new JLabel("Trình độ:");
        lbTrinhDo.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbTrinhDo);
        tfTrinhDo = new JTextField();
        panel.add(tfTrinhDo);

        // deal lương
        JLabel lbMucLuongDeal = new JLabel("Mức lương Deal:");
        lbMucLuongDeal.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbMucLuongDeal);
        tfDealLuong = new JTextField();
        panel.add(tfDealLuong);

        // trang thái
        JLabel lbTrangThai = new JLabel("Trạng thái:");
        lbTrangThai.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbTrangThai);
        
         cmbTrangThai = new JComboBox();
        cmbTrangThai.setModel(new DefaultComboBoxModel(new String[] {"Tuyen", "Chua tuyen"}));
        panel.add(cmbTrangThai);
        
//        tfTrangThai = new JTextField();
//        panel.add(tfTrangThai);
        
        

        // empty
        JLabel lbEmpty = new JLabel("");
        lbEmpty.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbEmpty);
        
        JLabel lbEmpty_1 = new JLabel("");
        lbEmpty_1.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(lbEmpty_1);

        // Button Thêm ứng viên
        JButton btnThemUV = new JButton("Thêm ứng viên");
        btnThemUV.setFont(new Font("Arial", Font.BOLD, 14));
        //btnThemNV.setBackground(new Color(0, 102, 204));
        btnThemUV.setForeground(Color.WHITE);
        btnThemUV.setBounds(275, 237, 200, 43);
        
        btnThemUV.setBorderPainted(false);
        btnThemUV.setBackground(Color.decode("#3498db"));
        btnThemUV.setFocusPainted(false);
        btnThemUV.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        getContentPane().add(btnThemUV);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(255, 255, 255));
        panel_1.setBounds(0, 221, 746, 66);
        getContentPane().add(panel_1);

        // Xử lý sự kiện khi click vào nút "Thêm nhân viên"
        btnThemUV.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lấy dữ liệu từ các trường nhập liệu

                
                 String maTuyenDung = tfMaUngVien.getText();
            	 String hoTen =tfTenUngVien.getText();
            	 String soDienThoai = tfSoDienThoai.getText();
            	 String email = tfEmail.getText();
            	 String chucVu = tfChucVu.getText();
            	 String trinhDo= tfTrinhDo.getText();
            	 int mucLuongDeal =Integer.parseInt(tfDealLuong.getText()) ;
            	 String trangThai= (String) cmbTrangThai.getSelectedItem();

                // Tạo đối tượng NhanVien và thêm vào cơ sở dữ liệu
                TuyenDung ungVien = new TuyenDung(maTuyenDung, hoTen, soDienThoai, email, chucVu, trinhDo, mucLuongDeal, trangThai);
                TuyenDungDAO tuyenDungDAO = TuyenDungDAO.getInstance();

                // Thực hiện thêm nhân viên vào cơ sở dữ liệu
                int result = tuyenDungDAO.insert(ungVien);

                if (result > 0) {
                    JOptionPane.showMessageDialog(null, "Thêm ứng viên thành công!");
                } else {
                    JOptionPane.showMessageDialog(null, "Thêm ứng viên thất bại!");
                }
            }
        });
    }
}


