package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import database.ConnectionDB;
import model.PhongBan;

public class PhongBanDAO implements DAOInterface<PhongBan> {

    public static PhongBanDAO getInstance() {
        return new PhongBanDAO();
    }

    @Override
    public int insert(PhongBan t) {
        int check = 0;
        try {
            Connection con = ConnectionDB.getConnection();
            Statement st = con.createStatement();

            String sql = "INSERT INTO PhongBan (MaPhongBan, TenPhongBan, NgayThanhLap, TruongPhong, NgayNhanChuc, SoLuongNhanVien, LuongTrungBinh) "
                    + "VALUES ('" + t.getMaPhongBan() + "', '" + t.getTenPhongBan() + "', '" + t.getNgayThanhLap() + "', '" + t.getTruongPhong() + "', '" + t.getNgayNhanChuc() + "', " + t.getSoLuongNhanVien() + ", " + t.getLuongTrungBinh() + ")";

            check = st.executeUpdate(sql);

            if (check > 0) {
                System.out.println("Thêm thành công");
            } else {
                System.out.println("Thêm thất bại");
            }

            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return check;
    }

    @Override
    public int update(PhongBan t) {
        int check = 0;
        try {
            Connection con = ConnectionDB.getConnection();
            Statement st = con.createStatement();

            String sql = "UPDATE PhongBan SET "
                    + "TenPhongBan = '" + t.getTenPhongBan() + "', "
                    + "NgayThanhLap = '" + t.getNgayThanhLap() + "', "
                    + "TruongPhong = '" + t.getTruongPhong() + "', "
                    + "NgayNhanChuc = '" + t.getNgayNhanChuc() + "', "
                    + "SoLuongNhanVien = " + t.getSoLuongNhanVien() + ", "
                    + "LuongTrungBinh = " + t.getLuongTrungBinh() + " "
                    + "WHERE MaPhongBan = '" + t.getMaPhongBan() + "'";

            check = st.executeUpdate(sql);

            if (check > 0) {
                System.out.println("Cập nhật thành công");
            } else {
                System.out.println("Cập nhật thất bại");
            }

            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return check;
    }

    @Override
    public int delete(PhongBan t) {
        int check = 0;
        try {
            Connection con = ConnectionDB.getConnection();
            Statement st = con.createStatement();

            String sql = "DELETE FROM PhongBan WHERE MaPhongBan = '" + t.getMaPhongBan() + "'";

            check = st.executeUpdate(sql);

            if (check > 0) {
                System.out.println("Xóa thành công");
            } else {
                System.out.println("Xóa thất bại");
            }

            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return check;
    }

    @Override
    public PhongBan selectById(PhongBan t) {
        PhongBan ketQua = null;
        try {
            Connection con = ConnectionDB.getConnection();
            Statement st = con.createStatement();

            String sql = "SELECT * FROM PhongBan WHERE MaPhongBan = '" + t.getMaPhongBan() + "'";

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                ketQua = new PhongBan(
                        rs.getString("MaPhongBan"),
                        rs.getString("TenPhongBan"),
                        rs.getString("NgayThanhLap"),
                        rs.getString("TruongPhong"),
                        rs.getString("NgayNhanChuc"),
                        rs.getInt("SoLuongNhanVien"),
                        rs.getInt("LuongTrungBinh")
                );
            }

            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ketQua;
    }

    @Override
    public ArrayList<PhongBan> selectByCondition(String condition) {
        ArrayList<PhongBan> ketQua = new ArrayList<>();
        try {
            Connection con = ConnectionDB.getConnection();
            Statement st = con.createStatement();

            String sql = "SELECT * FROM PhongBan WHERE " + condition;

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                PhongBan pb = new PhongBan(
                        rs.getString("MaPhongBan"),
                        rs.getString("TenPhongBan"),
                        rs.getString("NgayThanhLap"),
                        rs.getString("TruongPhong"),
                        rs.getString("NgayNhanChuc"),
                        rs.getInt("SoLuongNhanVien"),
                        rs.getInt("LuongTrungBinh")
                );
                ketQua.add(pb);
            }

            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ketQua;
    }

    @Override
    public ArrayList<PhongBan> selectALL() {
        ArrayList<PhongBan> ketQua = new ArrayList<>();
        try {
            Connection con = ConnectionDB.getConnection();
            Statement st = con.createStatement();

            String sql = "SELECT * FROM PhongBan";

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                PhongBan pb = new PhongBan(
                        rs.getString("MaPhongBan"),
                        rs.getString("TenPhongBan"),
                        rs.getString("NgayThanhLap"),
                        rs.getString("TruongPhong"),
                        rs.getString("NgayNhanChuc"),
                        rs.getInt("SoLuongNhanVien"),
                        rs.getInt("LuongTrungBinh")
                );
                ketQua.add(pb);
            }

            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ketQua;
    }
    public List<PhongBan> getPhongBanStatistics() {
        List<PhongBan> phongBans = new ArrayList<>();
        String query = "SELECT TenPhongBan, LuongTrungBinh, SoLuongNhanVien FROM PhongBan";
        try (Connection conn = ConnectionDB.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                PhongBan pb = new PhongBan();
                pb.setTenPhongBan(rs.getString("TenPhongBan"));
                pb.setLuongTrungBinh(rs.getInt("LuongTrungBinh"));
                pb.setSoLuongNhanVien(rs.getInt("SoLuongNhanVien"));
                phongBans.add(pb);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return phongBans;
    }

    // Truy vấn tỉ lệ giữa các phòng ban
    public List<PhongBan> getPhongBanCount() {
        List<PhongBan> phongBans = new ArrayList<>();
        String query = "SELECT TenPhongBan, COUNT(*) AS SoLuong FROM PhongBan GROUP BY TenPhongBan";
        try (Connection conn = ConnectionDB.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                PhongBan pb = new PhongBan();
                pb.setTenPhongBan(rs.getString("TenPhongBan"));
                pb.setSoLuongNhanVien(rs.getInt("SoLuong"));
                phongBans.add(pb);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return phongBans;
    }

    
}