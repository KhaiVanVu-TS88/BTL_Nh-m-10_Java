package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import database.ConnectionDB;
import model.ChamCong;
import model.NhanVien;

public class ChamCongDAO implements DAOInterface<ChamCong>{

	public static ChamCongDAO getInstance() {
		return new ChamCongDAO();
	}
	@Override
	public int insert(ChamCong t) {
		// TODO Auto-generated method stub
		int check =0;
		
		try {
			//buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();
			//buoc 2: tao statement
			Statement st = con.createStatement();
			//buoc 3: tao cau lenh sql
			String sql = "insert into ChamCong (MaChamCong, MaNhanVien, ThoiGian, NgayCong, SoNgayNghi, GioLamThem)"
					+" values ('"+t.getMaChamCong()+"' , '"+t.getMaNhanVien()+"' , '"+t.getThoiGian()+"' , "+t.getNgayCong()+" , "+ t.getSoNgayNghi()+" , "+t.getGioLamThem() +")";
			
			check = st.executeUpdate(sql);
			//buoc 4: xu lý ket qua
			System.out.println(sql);
			if (check >0) {
				System.out.println("Them thanh cong");
			} else {
				System.out.println("Them that bai");
			}
			
			//buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return check;
	}

	@Override
	public int update(ChamCong t) {
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "UPDATE ChamCong" + " SET " + " MaNhanVien ='" + t.getMaNhanVien() + "'" + ", ThoiGian ='"
					+ t.getThoiGian() + "'" + ", NgayCong =" + t.getNgayCong() + "" + ", SoNgayNghi   =" + t.getSoNgayNghi()
					+ ", GioLamThem ='" + t.getGioLamThem() + "'" 
					+ " WHERE MaChamCong='" + t.getMaChamCong() + "'";

			check = st.executeUpdate(sql);
			// buoc 4: xu ly ket qua
			System.out.println("so dong thay doi " + check);
			System.out.println(sql);
			if (check > 0) {
				System.out.println("sua doi thanh cong");
			} else {
				System.out.println("that bai");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return check;
	}
	
	public int updateNgayCong(ChamCong t) {
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "UPDATE ChamCong SET NgayCong =" + t.getNgayCong()
					+ " WHERE MaChamCong='" + t.getMaChamCong() + "'";

			check = st.executeUpdate(sql);
			// buoc 4: xu ly ket qua
			System.out.println("so dong thay doi " + check);
			System.out.println(sql);
			if (check > 0) {
				System.out.println("sua doi thanh cong");
			} else {
				System.out.println("that bai");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return check;
	}
	
	public int updateSoNgayNghi(ChamCong t) {
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "UPDATE ChamCong SET SoNgayNghi =" + t.getSoNgayNghi()
					+ " WHERE MaChamCong='" + t.getMaChamCong() + "'";

			check = st.executeUpdate(sql);
			// buoc 4: xu ly ket qua
			System.out.println("so dong thay doi " + check);
			System.out.println(sql);
			if (check > 0) {
				System.out.println("sua doi thanh cong");
			} else {
				System.out.println("that bai");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return check;
	}
	
	public int updateGioLamThem(ChamCong t) {
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "UPDATE ChamCong SET GioLamThem =" + t.getGioLamThem()
					+ " WHERE MaChamCong='" + t.getMaChamCong() + "'";

			check = st.executeUpdate(sql);
			// buoc 4: xu ly ket qua
			System.out.println("so dong thay doi " + check);
			System.out.println(sql);
			if (check > 0) {
				System.out.println("sua doi thanh cong");
			} else {
				System.out.println("that bai");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return check;
	}

	@Override
	public int delete(ChamCong t) {
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "DELETE from ChamCong" + " WHERE MaChamCong='" + t.getMaChamCong() + "'";

			check = st.executeUpdate(sql);
			// buoc 4: xu ly ket qua
			System.out.println("so dong thay doi " + check);
			System.out.println(sql);
			if (check > 0) {
				System.out.println("xoa thanh cong");
			} else {
				System.out.println("that bai");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return check;
	}

	@Override
	public ChamCong selectById(ChamCong t) {
		ChamCong ketQua = null;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "SELECT * from ChamCong WHERE MaChamCong ='" + t.getMaChamCong() + "'";

			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);

			// buoc 4: xu ly ket qua
			while (rs.next()) {
				String maChamCong = rs.getString("MaChamCong");
				String maNhanVien = rs.getString("MaNhanVien");
				String thoiGian = rs.getString("ThoiGian");
				int ngayCong = rs.getInt("NgayCong");
				int soNgayNghi = rs.getInt("SoNgayNghi");
				int gioLamThem = rs.getInt("GioLamThem");

				ketQua = new ChamCong(maChamCong, maNhanVien, thoiGian, ngayCong, soNgayNghi, gioLamThem);
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return ketQua;
	}

	@Override
	public ArrayList<ChamCong> selectByCondition(String Condition) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ArrayList<ChamCong> selectALL() {
		ArrayList<ChamCong> ketQua = new ArrayList<ChamCong>();
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "SELECT * from ChamCong";

			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);

			// buoc 4: xu ly ket qua
			while (rs.next()) {
				String maChamCong = rs.getString("MaChamCong");
				String maNhanVien = rs.getString("MaNhanVien");
				String thoiGian = rs.getString("ThoiGian");
				int ngayCong = rs.getInt("NgayCong");
				int soNgayNghi = rs.getInt("SoNgayNghi");
				int gioLamThem = rs.getInt("GioLamThem");


				ChamCong chamCong = new ChamCong(maChamCong, maNhanVien, thoiGian, ngayCong, soNgayNghi, gioLamThem);
				ketQua.add(chamCong);
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return ketQua;
	}
	

}
