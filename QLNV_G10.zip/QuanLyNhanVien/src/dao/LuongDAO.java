package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import database.ConnectionDB;
import model.Luong;

public class LuongDAO implements DAOInterface<Luong> {

    public static LuongDAO getInstance() {
        return new LuongDAO();
    }

    @Override
    public int insert(Luong t) {
        int result = 0;
        try {
            // Buoc 1: Tao lien ket
            Connection con = ConnectionDB.getConnection();

            // Buoc 2: Tao cau lenh SQL
            String sql = "INSERT INTO luong (MaLuong, MaNhanVien, ThoiGian, LuongCoBan, PhuCap, Thuong, Phat, Thue, ThucLanh) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            // Buoc 3: Tao PreparedStatement
            PreparedStatement ps = con.prepareStatement(sql);

            // Buoc 4: Gan gia tri cho PreparedStatement
            ps.setString(1, t.getMaLuong());
            ps.setString(2, t.getMaNhanVien());
            ps.setString(3, t.getThoiGian());
            ps.setInt(4, t.getLuongCoBan());
            ps.setInt(5, t.getPhuCap());
            ps.setInt(6, t.getThuong());
            ps.setInt(7, t.getPhat());
            ps.setInt(8, t.getThue());
            ps.setInt(9, t.getThucLanh());

            // Buoc 5: Thuc thi
            result = ps.executeUpdate();

            // Buoc 6: Ngat ket noi
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public int update(Luong t) {
        int result = 0;
        try {
            // Buoc 1: Tao lien ket
            Connection con = ConnectionDB.getConnection();

            // Buoc 2: Tao cau lenh SQL
            String sql = "UPDATE luong SET MaNhanVien = ?, ThoiGian = ?, LuongCoBan = ?, PhuCap = ?, Thuong = ?, Phat = ?, Thue = ?, ThucLanh = ? WHERE MaLuong = ?";

            // Buoc 3: Tao PreparedStatement
            PreparedStatement ps = con.prepareStatement(sql);

            // Buoc 4: Gan gia tri cho PreparedStatement
            ps.setString(1, t.getMaNhanVien());
            ps.setString(2, t.getThoiGian());
            ps.setInt(3, t.getLuongCoBan());
            ps.setInt(4, t.getPhuCap());
            ps.setInt(5, t.getThuong());
            ps.setInt(6, t.getPhat());
            ps.setInt(7, t.getThue());
            ps.setInt(8, t.getThucLanh());
            ps.setString(9, t.getMaLuong());

            // Buoc 5: Thuc thi
            result = ps.executeUpdate();
            

            // Buoc 6: Ngat ket noi
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public int delete(Luong t) {
        int result = 0;
        try {
            // Buoc 1: Tao lien ket
            Connection con = ConnectionDB.getConnection();

            // Buoc 2: Tao cau lenh SQL
            String sql = "DELETE FROM luong WHERE MaLuong = ?";

            // Buoc 3: Tao PreparedStatement
            PreparedStatement ps = con.prepareStatement(sql);

            // Buoc 4: Gan gia tri cho PreparedStatement
            ps.setString(1, t.getMaLuong());

            // Buoc 5: Thuc thi
            result = ps.executeUpdate();

            // Buoc 6: Ngat ket noi
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public Luong selectById(Luong t) {
        Luong luong = null;
        try {
            // Buoc 1: Tao lien ket
            Connection con = ConnectionDB.getConnection();

            // Buoc 2: Tao cau lenh SQL
            String sql = "SELECT * FROM luong WHERE MaLuong = ?";

            // Buoc 3: Tao PreparedStatement
            PreparedStatement ps = con.prepareStatement(sql);

            // Buoc 4: Gan gia tri cho PreparedStatement
            ps.setString(1, t.getMaLuong());

            // Buoc 5: Thuc thi
            ResultSet rs = ps.executeQuery();

            // Buoc 6: Xu ly ket qua
            if (rs.next()) {
                String maluong = rs.getString("MaLuong");
                String manv = rs.getString("MaNhanVien");
                String thoigian = rs.getString("ThoiGian");
                int luongcb = rs.getInt("LuongCoBan");
                int phucap = rs.getInt("PhuCap");
                int thuong = rs.getInt("Thuong");
                int phat = rs.getInt("Phat");
                int thue = rs.getInt("Thue");
//                int thuclanh = rs.getInt("ThucLanh");
//                luong = new Luong(maluong, manv, thoigian, luongcb, phucap, thuong, phat, thue, thuclanh);
                
                luong = new Luong(maluong, manv, thoigian, luongcb, phucap, thuong, phat, thue,luongcb+phucap+thuong-phat-thue);
            }

            // Buoc 7: Ngat ket noi
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return luong;
    }

    @Override
    public ArrayList<Luong> selectByCondition(String condition) {
        ArrayList<Luong> ketQua = new ArrayList<Luong>();
        try {
            // Buoc 1: Tao lien ket
            Connection con = ConnectionDB.getConnection();

            // Buoc 2: Tao cau lenh SQL
            String sql = "SELECT * FROM luong WHERE " + condition;

            // Buoc 3: Thuc thi
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            // Buoc 4: Xu ly ket qua
            while (rs.next()) {
                String maluong = rs.getString("MaLuong");
                String manv = rs.getString("MaNhanVien");
                String thoigian = rs.getString("ThoiGian");
                int luongcb = rs.getInt("LuongCoBan");
                int phucap = rs.getInt("PhuCap");
                int thuong = rs.getInt("Thuong");
                int phat = rs.getInt("Phat");
                int thue = rs.getInt("Thue");
//                int thuclanh = rs.getInt("ThucLanh");
//                Luong luong = new Luong(maluong, manv, thoigian, luongcb, phucap, thuong, phat, thue, thuclanh);
               
                Luong luong = new Luong(maluong, manv, thoigian, luongcb, phucap, thuong, phat, thue,luongcb+phucap+thuong-phat-thue);
                ketQua.add(luong);
            }

            // Buoc 5: Ngat ket noi
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    @Override
    public ArrayList<Luong> selectALL() {
        ArrayList<Luong> ketQua = new ArrayList<Luong>();
        try {
            // Buoc 1: Tao lien ket
            Connection con = ConnectionDB.getConnection();

            // Buoc 2: Tao ra doi tuong statement
            Statement st = con.createStatement();

            // Buoc 3: Thuc thi cau lenh SQL
            String sql = "SELECT * from luong";

            ResultSet rs = st.executeQuery(sql);

            // Buoc 4: Xu ly ket qua
            while (rs.next()) {
                String maluong = rs.getString("MaLuong");
                String manv = rs.getString("MaNhanVien");
                String thoigian = rs.getString("ThoiGian");
                int luongcb = rs.getInt("LuongCoBan");
                int phucap = rs.getInt("PhuCap");
                int thuong = rs.getInt("Thuong");
                int phat = rs.getInt("Phat");
                int thue = rs.getInt("Thue");
//                int thuclanh = rs.getInt("ThucLanh");
//                Luong luong = new Luong(maluong, manv, thoigian, luongcb, phucap, thuong, phat, thue, thuclanh);
                Luong luong = new Luong(maluong, manv, thoigian, luongcb, phucap, thuong, phat, thue,luongcb+phucap+thuong-phat-thue);
                ketQua.add(luong);
            }

            // Buoc 5: Ngat ket noi
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ketQua;
    }
    
    public static String getMaluongByMaNV(String maNV) {
String query = "SELECT MaLuong FROM Luong WHERE maNhanVien = ?";
        
        try (Connection conn = ConnectionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, maNV);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("MaLuong");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";  // Nếu không tìm thấy tên nhân viên
    	
    }
    

    
}
