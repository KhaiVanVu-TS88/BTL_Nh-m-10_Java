package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import database.ConnectionDB;
import model.NhanVien;
import model.TuyenDung;

public class TuyenDungDAO implements DAOInterface<TuyenDung> {

	public static TuyenDungDAO getInstance() {
		return new TuyenDungDAO();
	}

	@Override
	public int insert(TuyenDung t) {
		int check = 0;
		// TODO Auto-generated method stub
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2: tao mot doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: tao cau lenh sql
			String sql = "INSERT into tuyendung (MaTuyenDung, HoTen, SoDienThoai, Email, ChucVu, TrinhDo, MucLuongDeal, TrangThai)"
					+ " VALUES ('" + t.getMaTuyenDung() + "' , '" + t.getHoTen() + "' , '" + t.getSoDienThoai()
					+ "' , '" + t.getEmail() + "' , '" + t.getChucVu() + "' , '" + t.getTrinhDo() + "' , '"
					+ t.getMucLuongDeal() + "' , '" + t.getTrangThai() + "')";

			check = st.executeUpdate(sql);

			// buoc 4: xu lý ket qua
			System.out.println(sql);
			if (check > 0) {
				System.out.println("Thêm thành công!");
			} else {
				System.out.println("Thất bại!");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return check;
	}

	@Override
	public int update(TuyenDung t) {
		// TODO Auto-generated method stub
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2: tao mot doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: tao cau lenh thuc thi sql
			String sql = "UPDATE TuyenDung " + "SET " + "HoTen = '" + t.getHoTen() + "'" + ",SoDienThoai ='"
					+ t.getSoDienThoai() + "'" + ",Email ='" + t.getEmail() + "'" + ",ChucVu ='" + t.getChucVu() + "'"
					+ ",TrinhDo ='" + t.getTrinhDo() + "'" + ",MucLuongDeal ='" + t.getMucLuongDeal() + "'"
					+ ",TrangThai ='" + t.getTrangThai() + "'" + "WHERE MaTuyenDung ='" + t.getMaTuyenDung() + "'";
			check = st.executeUpdate(sql);

			// buoc 4: xu ly ket qua
			System.out.println(sql);
			if (check > 0) {
				System.out.println("Update thanh cong!");
			} else {
				System.out.println("Update that bai!");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return check;
	}

	@Override
	public int delete(TuyenDung t) {
		// TODO Auto-generated method stub
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2: tao doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: tao cau lenh sql
			String sql = "DELETE FROM TuyenDung WHERE MaTuyenDung ='" + t.getMaTuyenDung() + "'";

			check = st.executeUpdate(sql);
			// buoc 4: xu ly ket qua
			if (check > 0) {
				System.out.println("Xoa thanh cong!");
			} else {
				System.out.println("Xoa that bai!");
			}

			// buoc 5:ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return check;
	}

	@Override
	public TuyenDung selectById(TuyenDung t) {
		// TODO Auto-generated method stub
		TuyenDung ketQua = null;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2: tao doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: tao cau lenh sql
			String sql = "SELECT * FROM TUYENDUNG WHERE MaTuyenDung ='" + t.getMaTuyenDung() + "'";

			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);
			// buoc 4: xu ly ket qua
			while (rs.next()) {
				String maTuyenDung = rs.getString("MaTuyenDung");
				String hoTen = rs.getString("HoTen");
				String soDienThoai = rs.getString("SoDienThoai");
				String email = rs.getString("Email");
				String chucVu = rs.getString("ChucVu");
				String trinhDo = rs.getString("TrinhDo");
				int mucLuongDeal = rs.getInt("MucLuongDeal");
				String trangThai = rs.getString("TrangThai");

				ketQua = new TuyenDung(maTuyenDung, hoTen, soDienThoai, email, chucVu, trinhDo, mucLuongDeal,
						trangThai);
			}

			//System.out.println(ketQua.toString());
			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return ketQua;
	}

	@Override
	public ArrayList<TuyenDung> selectByCondition(String Condition) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<TuyenDung> selectALL() {
		// TODO Auto-generated method stub
		ArrayList<TuyenDung> ketQua = new ArrayList<TuyenDung>();
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2: tao doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: tao cau lenh sql
			String sql = "SELECT * FROM TuyenDung";
			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);

			// buoc 4: xu lys ket qua
			while (rs.next()) {
				String maTuyenDung = rs.getString("MaTuyenDung");
				String hoTen = rs.getString("HoTen");
				String soDienThoai = rs.getString("SoDienThoai");
				String email = rs.getString("Email");
				String chucVu = rs.getString("ChucVu");
				String trinhDo = rs.getString("TrinhDo");
				int mucLuongDeal = rs.getInt("MucLuongDeal");
				String trangThai = rs.getString("TrangThai");
				TuyenDung tuyenDung = new TuyenDung(maTuyenDung, hoTen, soDienThoai, email, chucVu, trinhDo,
						mucLuongDeal, trangThai);
				ketQua.add(tuyenDung);

			}
			
			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return ketQua;
	}
	
	public int tuyen(TuyenDung t) {
		int check =0;
		try {
			//buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();
			
			//buoc 2: tao doi tuong statement
			Statement st = con.createStatement();
			
			//buoc 3: tao cau lenh sql
			String sql = "UPDATE TuyenDung SET TrangThai = 'Tuyen' WHERE MaTuyenDung ='"+t.getMaTuyenDung()+"'";
			
			System.out.println();
			check = st.executeUpdate(sql);
			//buoc 4: xu lu
			if (check >0) {
				System.out.println("Tuyen thanh cong!");
			}else {
				System.out.println("Tuyen that bai!");
			}
			
			//buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return check;
	}

}
