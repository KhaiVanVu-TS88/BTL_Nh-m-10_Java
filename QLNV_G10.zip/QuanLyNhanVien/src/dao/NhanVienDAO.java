package dao;

import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import database.ConnectionDB;
import model.NhanVien;

public class NhanVienDAO implements DAOInterface<NhanVien> {

	public static NhanVienDAO getInstance() {
		return new NhanVienDAO();
	}

	@Override
	public int insert(NhanVien t) {
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "INSERT INTO nhanvien (MaNhanVien, TenNhanVien, GioiTinh, NgaySinh, DiaChi, SoDienThoai, MaPhongBan, ChucVu, MucLuong)"
					+ " VALUES ('" + t.getMaNhanVien() + "' , '" + t.getTenNhanVien() + "' , '" + t.getGioiTinh()
					+ "' , '" + t.getNgaySinh() + "' , '" + t.getDiaChi() + "' , '" + t.getSoDienThoai() + "' , '"
					+ t.getMaPhongBan() + "' , '" + t.getChucVu() + "' , " + t.getMucLuong() + ")";

			check = st.executeUpdate(sql);
			// buoc 4: xu ly ket qua
			System.out.println("so dong thay doi " + check);
			if (check > 0) {
				System.out.println("them thanh cong");
			} else {
				System.out.println("that bai");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return check;
	}

	@Override
	public int update(NhanVien t) {
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "UPDATE NhanVien" + " SET " + " TenNhanVien ='" + t.getTenNhanVien() + "'" + ", GioiTinh ='"
					+ t.getGioiTinh() + "'" + ", NgaySinh ='" + t.getNgaySinh() + "'" + ", DiaChi   ='" + t.getDiaChi()
					+ "'" + ", SoDienThoai ='" + t.getSoDienThoai() + "'" + ", MaPhongBan  ='" + t.getMaPhongBan() + "'"
					+ ", ChucVu      ='" + t.getChucVu() + "'" + ", MucLuong    ='" + t.getMucLuong() + "'"
					+ " WHERE MaNhanVien='" + t.getMaNhanVien() + "'";

			check = st.executeUpdate(sql);
			// buoc 4: xu ly ket qua
			System.out.println("so dong thay doi " + check);
			System.out.println(sql);
			if (check > 0) {
				System.out.println("sua doi thanh cong");
			} else {
				System.out.println("that bai");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return check;
	}

	@Override
	public int delete(NhanVien t) {
		int check = 0;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "DELETE from NhanVien" + " WHERE MaNhanVien='" + t.getMaNhanVien() + "'";

			check = st.executeUpdate(sql);
			// buoc 4: xu ly ket qua
			System.out.println("so dong thay doi " + check);
			System.out.println(sql);
			if (check > 0) {
				System.out.println("xoa thanh cong");
			} else {
				System.out.println("that bai");
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return check;
	}

	@Override
	public NhanVien selectById(NhanVien t) {
		NhanVien ketQua = null;
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "SELECT * from NhanVien WHERE MaNhanVien ='" + t.getMaNhanVien() + "'";

			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);

			// buoc 4: xu ly ket qua
			while (rs.next()) {
				String maNhanVien = rs.getString("MaNhanVien");
				String tenNhanVien = rs.getString("TenNhanVien");
				String gioiTinh = rs.getString("GioiTinh");
				String ngaySinh = rs.getString("NgaySinh");
				String diaChi = rs.getString("DiaChi");
				String soDienThoai = rs.getString("SoDienThoai");
				String maPhongBan = rs.getString("MaPhongBan");
				String chucVu = rs.getString("ChucVu");
				int mucLuong = rs.getInt("MucLuong");

				ketQua = new NhanVien(maNhanVien, tenNhanVien, gioiTinh, ngaySinh, diaChi, soDienThoai, maPhongBan,
						chucVu, mucLuong);
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return ketQua;
	}

	@Override
	public ArrayList<NhanVien> selectByCondition(String condition) {
		ArrayList<NhanVien> ketQua = new ArrayList<NhanVien>();
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "SELECT * from NhanVien WHERE TenNhanVien ='"+condition+"'";

			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);

			// buoc 4: xu ly ket qua
			while (rs.next()) {
				String maNhanVien = rs.getString("MaNhanVien");
				String tenNhanVien = rs.getString("TenNhanVien");
				String gioiTinh = rs.getString("GioiTinh");
				String ngaySinh = rs.getString("NgaySinh");
				String diaChi = rs.getString("DiaChi");
				String soDienThoai = rs.getString("SoDienThoai");
				String maPhongBan = rs.getString("MaPhongBan");
				String chucVu = rs.getString("ChucVu");
				int mucLuong = rs.getInt("MucLuong");

				NhanVien nhanVien = new NhanVien(maNhanVien, tenNhanVien, gioiTinh, ngaySinh, diaChi, soDienThoai,
						maPhongBan, chucVu, mucLuong);
				ketQua.add(nhanVien);
			}
			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return ketQua;
	}

	@Override
	public ArrayList<NhanVien> selectALL() {
		ArrayList<NhanVien> ketQua = new ArrayList<NhanVien>();
		try {
			// buoc 1: tao lien ket
			Connection con = ConnectionDB.getConnection();

			// buoc 2:tao ra doi tuong statement
			Statement st = con.createStatement();

			// buoc 3: thuc thi cau lệnh SQL
			String sql = "SELECT * from NhanVien";

			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);

			// buoc 4: xu ly ket qua
			while (rs.next()) {
				String maNhanVien = rs.getString("MaNhanVien");
				String tenNhanVien = rs.getString("TenNhanVien");
				String gioiTinh = rs.getString("GioiTinh");
				String ngaySinh = rs.getString("NgaySinh");
				String diaChi = rs.getString("DiaChi");
				String soDienThoai = rs.getString("SoDienThoai");
				String maPhongBan = rs.getString("MaPhongBan");
				String chucVu = rs.getString("ChucVu");
				int mucLuong = rs.getInt("MucLuong");

				NhanVien nhanVien = new NhanVien(maNhanVien, tenNhanVien, gioiTinh, ngaySinh, diaChi, soDienThoai,
						maPhongBan, chucVu, mucLuong);
				ketQua.add(nhanVien);
			}

			// buoc 5: ngat ket noi
			ConnectionDB.closeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return ketQua;
	}
	public String getTenNhanVienByMa(String maNhanVien) {
        // Truy vấn cơ sở dữ liệu để lấy tên nhân viên theo mã nhân viên
        // Giả sử bạn có một câu lệnh SQL để lấy tên nhân viên
        String query = "SELECT TenNhanVien FROM NhanVien WHERE maNhanVien = ?";
        
        try (Connection conn = ConnectionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, maNhanVien);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("tenNhanVien");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";  // Nếu không tìm thấy tên nhân viên
    }

	public int getLuongCB(String maNhanVien) {
String query = "SELECT MucLuong FROM NhanVien WHERE maNhanVien = ?";
        
        try (Connection conn = ConnectionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, maNhanVien);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("MucLuong");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;  // Nếu không tìm thấy tên nhân viên
	}

	
}
