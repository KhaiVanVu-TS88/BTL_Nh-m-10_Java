// taiKhoanDAO
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import database.ConnectionDB;
import model.TaiKhoan;

public class TaiKhoanDAO implements DAOInterface<TaiKhoan> {

    public static TaiKhoanDAO getInstance() {
        return new TaiKhoanDAO();
    }

    @Override
    public int insert(TaiKhoan t) {
        int check = 0;
        try {
            // Step 1: Create connection
            Connection con = ConnectionDB.getConnection();

            // Step 2: Create statement
            Statement st = con.createStatement();

            // Step 3: Execute SQL query
            String sql = "INSERT INTO taikhoan (MaNhanVien, Quyen) VALUES ('" 
                         + t.getMaNhanVien() + "', '" 
                         + t.getQuyen() + "')";
            check = st.executeUpdate(sql);

            // Step 4: Handle result
            System.out.println("Rows affected: " + check);
            if (check > 0) {
                System.out.println("Insert successful");
            } else {
                System.out.println("Insert failed");
            }

            // Step 5: Close connection
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return check;
    }

    @Override
    public int update(TaiKhoan t) {
        int check = 0;
        try {
            // Step 1: Create connection
            Connection con = ConnectionDB.getConnection();

            // Step 2: Create statement
            Statement st = con.createStatement();

            // Step 3: Execute SQL query
            String sql = "UPDATE taikhoan SET Quyen = '" + t.getQuyen() + "' WHERE MaNhanVien = '" + t.getMaNhanVien() + "'";
            check = st.executeUpdate(sql);

            // Step 4: Handle result
            System.out.println("Rows affected: " + check);
            if (check > 0) {
                System.out.println("Update successful");
            } else {
                System.out.println("Update failed");
            }

            // Step 5: Close connection
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return check;
    }

    @Override
    public int delete(TaiKhoan t) {
        int check = 0;
        try {
            // Step 1: Create connection
            Connection con = ConnectionDB.getConnection();

            // Step 2: Create statement
            Statement st = con.createStatement();

            // Step 3: Execute SQL query
            String sql = "DELETE FROM taikhoan WHERE MaNhanVien = '" + t.getMaNhanVien() + "'";
            check = st.executeUpdate(sql);

            // Step 4: Handle result
            System.out.println("Rows affected: " + check);
            if (check > 0) {
                System.out.println("Delete successful");
            } else {
                System.out.println("Delete failed");
            }

            // Step 5: Close connection
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return check;
    }

    @Override
    public TaiKhoan selectById(TaiKhoan t) {
        TaiKhoan result = null;
        try {
            // Step 1: Create connection
            Connection con = ConnectionDB.getConnection();

            // Step 2: Create statement
            Statement st = con.createStatement();

            // Step 3: Execute SQL query
            String sql = "SELECT * FROM taikhoan WHERE MaNhanVien = '" + t.getMaNhanVien() + "'";
            ResultSet rs = st.executeQuery(sql);

            // Step 4: Process result
            if (rs.next()) {
                String maNhanVien = rs.getString("MaNhanVien");
                String quyen = rs.getString("Quyen");

                result = new TaiKhoan(maNhanVien, quyen);
            }

            // Step 5: Close connection
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    @Override
    public ArrayList<TaiKhoan> selectByCondition(String condition) {
        ArrayList<TaiKhoan> result = new ArrayList<>();
        try {
            // Step 1: Create connection
            Connection con = ConnectionDB.getConnection();

            // Step 2: Create statement
            Statement st = con.createStatement();

            // Step 3: Execute SQL query
            String sql = "SELECT * FROM taikhoan WHERE " + condition;
            ResultSet rs = st.executeQuery(sql);

            // Step 4: Process result
            while (rs.next()) {
                String maNhanVien = rs.getString("MaNhanVien");
                String quyen = rs.getString("Quyen");

                TaiKhoan taiKhoan = new TaiKhoan(maNhanVien, quyen);
                result.add(taiKhoan);
            }

            // Step 5: Close connection
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    @Override
    public ArrayList<TaiKhoan> selectALL() {
//        ArrayList<TaiKhoan> result = new ArrayList<>();
//        try {
//            // Step 1: Create connection
//            Connection con = ConnectionDB.getConnection();
//
//            // Step 2: Create statement
//            Statement st = con.createStatement();
//
//            // Step 3: Execute SQL query
//            String sql = "SELECT * FROM taikhoan";
//            ResultSet rs = st.executeQuery(sql);
//
//            // Step 4: Process result
//            while (rs.next()) {
//                String maNhanVien = rs.getString("MaNhanVien");
//                String quyen = rs.getString("Quyen");
//
//                TaiKhoan taiKhoan = new TaiKhoan(maNhanVien, quyen);
//                result.add(taiKhoan);
//            }
//
//            // Step 5: Close connection
//            ConnectionDB.closeConnection(con);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return result;
    	ArrayList<TaiKhoan> result = new ArrayList<>();
        try {
            // Step 1: Create connection
            Connection con = ConnectionDB.getConnection();

            // Step 2: Create statement
            String sql = "SELECT * FROM taikhoan";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            // Step 3: Process result
            while (rs.next()) {
                String maNhanVien = rs.getString("MaNhanVien");
                String quyen = rs.getString("Quyen");

                TaiKhoan taiKhoan = new TaiKhoan(maNhanVien, quyen);
                result.add(taiKhoan);
            }

            // Step 4: Close connection
            ConnectionDB.closeConnection(con);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}